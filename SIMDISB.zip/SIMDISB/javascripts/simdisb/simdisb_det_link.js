<!--	This is getting executing on click of submit and validate button -->
var acctCheck = "";
var notes=[],coins=[],arr=[];
var denonNum;

function fnValidateData() {
	
	var checkAcctNo = document.getElementById("acctNo").value;
	var checkAmt = document.getElementById("amt").value;
	
	if ((checkAcctNo == '')||(checkAcctNo == "")){
		alert("Enter a valid account number");
		document.getElementById("acctNo").focus();
		return false;
	}
	if ((checkAmt == '')||(checkAmt == "")){
		alert("Enter an amount");
		document.getElementById("amt").focus();
		return false;
	}
	
	
	if (!fnCheckMandatoryFields())
	{
		return false;
	}
	
	if(getValueData()==false){
		return false;
	}
	eraseCookie("totRecData");
	createCookie("totRecData",document.getElementById("CLN").value,0);
	createCookie("acctNo",document.getElementById("acctNo").value,0);
	createCookie("crcnyCode",document.getElementById("crcnyCode").value,0);
	createCookie("AcctName",document.getElementById("AcctName").value,0);
	createCookie("amt",document.getElementById("amt").value,0);
	createCookie("disbdAmt",document.getElementById("disbdAmt").value,0);
	createCookie("mnth",document.getElementById("mnth").value,0);
	createCookie("dayM",document.getElementById("dayM").value,0);
	createCookie("tranType",document.getElementById("tranTypeCash").value,0);
	createCookie("funcCode",document.getElementById("funcCode").value,0);
	createCookie("availDisbAmt",document.getElementById("availDisbAmt").value,0);
	createCookie("finDisb",document.getElementById("tranTypeGross").value,0);
	createCookie("groNetDisb",document.getElementById("finDisbYes").value,0);
	createCookie("totDisbAmts",document.getElementById("totDisbAmts").value,0);
	return true;
}




<!-- This function is added for formatting a particular MRH Row -->

function formatRowValue(Obj, colNumber) {

      return Obj;

       }


<!-- This function is added for formatting a particular MRH Row -->

function fnValidateForm(obj){
	objForm = document.forms[0];
	return true;
}

function fnVal(obj){
	if (obj.id == "Validate"){return false;}
}

function createCookie(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else{ 
		var expires = "";
		document.cookie = name+"="+value+expires+"; path=/";
	}
}

function eraseCookie(name) {
   createCookie(name,"",-1);
}
function readCookie(name)
{
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++)
	{
			var c = ca[i];
			while (c.charAt(0)==' ') c = c.substring(1,c.length);
			if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}


function disabler(){
	document.getElementById("ledgerBal").disabled = true;
	document.getElementById("effAvailBal").disabled = true;
	document.getElementById("availBal").disabled = true;
	document.getElementById("ShadowBal").disabled = true;
	//document.getElementById("tellerTillBal").disabled = true;
	
	document.getElementById("enteredDrCr").disabled = true;
	document.getElementById("PostedDrCr").disabled = true;
	document.getElementById("totalPartTnx").disabled = true;

	document.getElementById("firstName").disabled = true;
	document.getElementById("lastName").disabled = true;
	document.getElementById("address1").disabled = true;
	document.getElementById("address2").disabled = true;
	document.getElementById("phoneNo").disabled = true;
	document.getElementById("bvn2").disabled = true;

	for (i=1;i<=denomNum;i++){
		document.getElementById("Denom"+String(i)+"1").disabled = true;
		document.getElementById("Denom"+String(i)+"3").disabled = true;
		document.getElementById("Denom"+String(i)+"4").disabled = true;
		document.getElementById("Denom"+String(i)+"6").disabled = true;
	}
	document.getElementById("DenomAmt").disabled = true;
	document.getElementById("DenomAmtCrncy").disabled = true;
	document.getElementById("RoundOffAmt").disabled = true;

}

function lengthWord(arg){
   var txt = document.getElementById(arg).value;
   var length = txt.length;
   if(length >= 50){
	   document.getElementById(arg).value = txt.substring(0,49);
	  }  
     }

function clearDenom(){
	acctCheck = "";
	
	for (i=1;i<=denomNum;i++){
		document.getElementById("Denom"+String(i)+"1").style.display='';
		document.getElementById("Denom"+String(i)+"2").style.display='';
		document.getElementById("Denom"+String(i)+"3").style.display='';
		document.getElementById("Denom"+String(i)+"4").style.display='';
		document.getElementById("Denom"+String(i)+"5").style.display='';
		document.getElementById("Denom"+String(i)+"6").style.display='';

		document.getElementById("Denom"+String(i)+"1").value = '0';
		document.getElementById("Denom"+String(i)+"2").value = '0';
		document.getElementById("Denom"+String(i)+"3").value = '0';
		document.getElementById("Denom"+String(i)+"4").value = '0';
		document.getElementById("Denom"+String(i)+"5").value = '0';
		document.getElementById("Denom"+String(i)+"6").value = '0';

		document.getElementById("Denom"+String(i)+"1").disabled = true;	
		document.getElementById("Denom"+String(i)+"2").disabled = true;
		document.getElementById("Denom"+String(i)+"3").disabled = true;
		document.getElementById("Denom"+String(i)+"4").disabled = true;
		document.getElementById("Denom"+String(i)+"5").disabled = true;
		document.getElementById("Denom"+String(i)+"6").disabled = true;
	}
	document.getElementById("DenomAmt").value = '0';
	document.getElementById("DenomAmtCrncy").value = '';

	document.getElementById("DenomAmt").disabled = true;
	document.getElementById("DenomAmtCrncy").disabled = true;
	
}

function decLiterals2(obj){
	var amtVal = obj.value.replace(/\,/g,"");
	//alert("IN")
	//alert(amtVal)
	if (amtVal == ""){return false;}
	
	var res = amtVal.toUpperCase().substring(0, amtVal.length - 1);
	var res2 = amtVal.toUpperCase().slice(-1);
	var mon;

	if (res=="."){
		res=0;
	}
	if (res2=="."){
		res2=0;
	}
	if ((!Boolean(res))&&(isNaN(res2))){
		alert("Enter a valid amount");
		obj.focus();
		return false;
	}
	
	if (isNaN(res)){
			alert("Enter a valid amount");
			obj.focus();
			return false;
	}

	if (isNaN(res2)){
	switch (res2){
		case "T":
			mon = (Number(res) * 1000);
			if (checkDecLen(mon)){
				mon=mon.toFixed(2);
			}else{
				obj.focus();
				return false;
			}
			break;
		case "M":
			mon = (Number(res) * 1000000);
			if (checkDecLen(mon)){
				mon=mon.toFixed(2);
			}else{
				
				obj.focus();
				return false;
			}
			break;
		case "B":
			mon = (Number(res) * 1000000000);
			if (checkDecLen(mon)){
				mon=mon.toFixed(2);
			}else{
				
				obj.focus();
				return false;
			}
			break;
		default:
			alert("Enter a valid amount2");
			obj.focus();
			return false;
	}
	}else{
		if (isNaN(amtVal)){
			alert("Enter a valid number3");
			obj.focus();
			return false;

		}else{
		mon = (Number(amtVal) * 1);
		
		if (checkDecLen(mon)){
				mon=mon.toFixed(2);
			}else{
				
				obj.focus();
				return false;
			}
	}
	}
	var wholeRes = String(mon).split(".")[0];
	var decimalRes = String(mon).split(".")[1];


	//var amtVal2 = wholeRes.replace(/\B(?=(\d{3})+\b)/g, ",");
	//amtVal2 = wholeRes + "." + decimalRes;

	obj.value=wholeRes;
	/*if(obj.id =="totDisbAmts"){
		document.getElementById("disbAmt").value=wholeRes;
	}else{
		document.getElementById("disbAmt").value=wholeRes;
	}*/
}

function fnOnLoad(){
	acctCheck = "";
		var ObjForm = document.forms[0];
	
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!

	var yyyy = today.getFullYear();
	if(dd<10){
		dd='0'+dd;
	} 
	if(mm<10){
		mm='0'+mm;
	} 
	var today = dd+'-'+mm+'-'+yyyy;
	//
		//fetchCrncy(homeCrncyCode);
	createTable(1);
	addTable(10)
	document.getElementById("tranDate").value = BODDate;
	document.getElementById("valDate").value = BODDate;
	document.getElementById("solId").value = cSolId;
	document.getElementById("tranDate").disabled = true;
	document.getElementById("availDisbAmt").disabled = true;
	document.getElementById("solId").disabled = true;
	document.getElementById("disbdAmt").disabled = true;
	document.getElementById("tranTypeCash").disabled = true;
	document.getElementById("amt").disabled = true;	 
	document.getElementById("AcctName").disabled=true;
	
	var totRecData = readCookie("totRecData")
	if(!totRecData){
		//alert(totRecData)
	}else{
		//var totRecData = readCookie("totRecData")
		ObjForm.acctNo.value = readCookie("acctNo")
		ObjForm.crcnyCode.value = readCookie("crcnyCode")
		ObjForm.AcctName.value = readCookie("AcctName")
		ObjForm.amt.value = readCookie("amt")
		ObjForm.disbdAmt.value = readCookie("disbdAmt")
		ObjForm.mnth.value = readCookie("mnth")
		ObjForm.dayM.value = readCookie("dayM")
		var tranType = readCookie("tranType")
		ObjForm.funcCode.value = readCookie("funcCode")
		ObjForm.availDisbAmt.value = readCookie("availDisbAmt")
		var finDisb = readCookie("finDisb")
		var groNetDisb = readCookie("groNetDisb")
		if(finDisb=="Y"){
			document.getElementById("finDisbYes").checked=true;
		}else{
			document.getElementById("finDisbNo").checked=true;
		}
		if(groNetDisb=="G"){
			document.getElementById("tranTypeGross").checked=true;
		}else{
			document.getElementById("tranTypeNet").checked=true;
		}
		if(tranType=="T"){
			document.getElementById("tranTypeTran").checked=true;
		}else{
			document.getElementById("tranTypeCash").checked=true;
		}
		denomSplitter1(totRecData)
	}
	/*if ((totRecData.length == 0)||(totRecData== ""))
	{
		alert("Empty")
	}
	if((totRecData =="null")||(totRecData =="")){
		alert(totRecData)
	}
	else{
		denomSplitter1(totRecData)
	}*/
	
}

function fnClear(){
	createCookie("totRecData","",0);
	createCookie("acctNo","",0);
	createCookie("crcnyCode","",0);
	createCookie("AcctName","",0);
	createCookie("amt","",0);
	createCookie("disbdAmt","",0);
	createCookie("mnth","",0);
	createCookie("dayM","",0);
	createCookie("tranType","",0);
	createCookie("funcCode","",0);
	createCookie("availDisbAmt","",0);
	createCookie("finDisb","",0);
	createCookie("groNetDisb","",0);
	
	createTable(1);
	addTable(10)
	
}

function getValueData(){
	var funcCode = document.getElementById("funcCode").value.toUpperCase();
	numbs1=document.getElementById("nfiu").value 
	/*if(funcCode !="D"){
		numbs1 =Number(numbs1)-1
	}*/
	disbAmt= document.getElementById("disbAmt").value 
	totDisbAmts= document.getElementById("totDisbAmts").value 
	indAmtVal= document.getElementById("indAmtVal").value 
	indAmtVal= indAmtVal.replace(/\,/g,'')
	//alert(totDisbAmts)
	//alert(indAmtVal)
	/*if(disbAmt ==""){
		alert("Please enter Disbursement Amount")
		document.getElementById("disbAmt").focus()
		return false;
	}*/
	if(parseFloat(totDisbAmts) != parseFloat(indAmtVal)){
		alert("Total Disbursement amount must be equal to the amount disbursed")
		document.getElementById("totDisbAmts").focus()
		return false;
	}else{
		document.getElementById("disbAmt").value = document.getElementById("totDisbAmts").value
	}
	if(numbs1 !=""){
		recData =""
		totRecData =""
		//alert(numbs1)
		for (i=1;i<=numbs1;i++){
			//alert("finDisb"+String(i)+"1")
			var crAcctNum = document.getElementById("finDisb"+String(i)+"1").value
			var crAmt = document.getElementById("finDisb"+String(i)+"2").value
			//alert(crAcctNum)
			if(crAcctNum !=""){ //Validate credit amount only when account number is not emprty
				if(crAmt ==""){
					alert("Please enter Credit amount")
					document.getElementById("finDisb"+String(i)+"2").focus()
					return false;
				}
			}
			var disbCode = document.getElementById("finDisb"+String(i)+"3").value
			var acctId = document.getElementById("finDisb"+String(i)+"5").value
			var acctName = document.getElementById("finDisb"+String(i)+"6").value
			var amt2 = document.getElementById("finDisb"+String(i)+"7").value
			var dbInd = document.getElementById("finDisb"+String(i)+"8").value
			var chrgType = document.getElementById("finDisb"+String(i)+"9").value
			var recNum = document.getElementById("finDisb"+String(i)+"A").value
			//alert(recNum)
			//alert("finDisb"+String(i)+"A")
			if(dbInd =="DR"){
				if(chrgType !=""){
					recData = crAcctNum +","+ crAmt +","+ disbCode +","+ acctId +","+ acctName +","+ amt2 +","+ dbInd +"/"+ chrgType +","+ recNum
				}else{
					recData = crAcctNum +","+ crAmt +","+ disbCode +","+ acctId +","+ acctName +","+ amt2 +","+ dbInd +","+ recNum
				}
			}else{
				recData = crAcctNum +","+ crAmt +","+ disbCode +","+ acctId +","+ acctName +","+ amt2 +","+ dbInd +","+ recNum
			}
			totRecData = totRecData +"@"+ recData
		}
		//alert(totRecData)
		document.getElementById("CLN").value=totRecData 
	}else{
		alert("Please enter Disbursement details")
		document.getElementById("disbAmt").focus()
		return false;
	}
	
}

function fnValidateAcctData(){
	var checkAcctData = document.getElementById("acctNo").value;
	
	if ((checkAcctData == '')||(checkAcctData == "")){
		alert("Enter a valid account number");
		document.getElementById("acctNo").focus();
		return false;
	}
}
function checkDecLen(number){
	strVal=String(number);
	decState=strVal.match(/\.[\d]+/);
	if (decState){
		
		if (decState[0].length>3) {
			alert("number of decimal digits is more than 2");
			return false;
		}else{
			return true;
		}
	}else{
		return true;
	}
}


function formatAcct(acctNo){
	var inputNameValues = "step|3|acctNo|"+acctNo;
	var outputNames = "fAccount,Err1";
	var scrName = "simplify_submit3.scr";
	var retVal2 = appFnExecuteScript(inputNameValues,outputNames,scrName,false);					
	fAccount = retVal2.split("|")[1];
	document.getElementById("acctNo").value = fAccount;
	return fAccount
}

function denomSplitter1(arg){
	var funcCode = document.getElementById("funcCode").value.toUpperCase();
	arr= arg.split("@");
	denomNum=arg.split('@').length-1
	//alert(denomNum)
	len= arr.length-1;
	//alert(len)
	if(funcCode=="R"){
		if(arr[2].split(",")[0] !=""){
			alert("Reversal for multiple disbursement is not allowed use HLADISB")
			//addTablev(1);
			return false
		}else{
			addTablev(len);
		}
	}else{
		addTablev(len);
	}
	//addTablev(len);
	counter=1;
	var denomMainVal0=0;
	//alert(len)
	var totDisbAmt=0
	document.getElementById("nfiu").value =len
	//alert(document.getElementById("nfiu").value)
	var cnt=0
	
	while (counter<=len){
		//alert("finDisb"+String(counter)+"1")
		document.getElementById("finDisb"+String(counter)+"1").value = arr[counter].split(",")[0];
		document.getElementById("finDisb"+String(counter)+"2").value = arr[counter].split(",")[1];
		document.getElementById("finDisb"+String(counter)+"3").value = arr[counter].split(",")[2];
		document.getElementById("finDisb"+String(counter)+"5").value = arr[counter].split(",")[3];
		document.getElementById("finDisb"+String(counter)+"6").value = arr[counter].split(",")[4];
		document.getElementById("finDisb"+String(counter)+"7").value = arr[counter].split(",")[5];
		document.getElementById("finDisb"+String(counter)+"A").value = arr[counter].split(",")[7];
		//alert(arr[counter].split(",")[7])
		document.getElementById("finDisb"+String(counter)+"1").disabled = true
		document.getElementById("finDisb"+String(counter)+"2").disabled = true
		document.getElementById("finDisb"+String(counter)+"3").disabled = true
		document.getElementById("finDisb"+String(counter)+"5").disabled = true
		document.getElementById("finDisb"+String(counter)+"6").disabled = true
		document.getElementById("finDisb"+String(counter)+"7").disabled = true
		document.getElementById("finDisb"+String(counter)+"8").disabled = true
		
		//remove extra details coming from DB
		var crdr= arr[counter].split(",")[6];
		//alert(crdr)
		crdrlen = crdr.length
		if(crdr.substring(0,2) =="DR"){
			//alert(crdr.substring(3,Number(crdrlen)))
			document.getElementById("finDisb"+String(counter)+"8").value = "DR";
			document.getElementById("finDisb"+String(counter)+"9").value = crdr.substring(3,Number(crdrlen))
		}else{
			document.getElementById("finDisb"+String(counter)+"8").value = arr[counter].split(",")[6];
		}
		//Get total disbursement Amount
		var disbAmt =arr[counter].split(",")[1];
		if(disbAmt !=""){
			cnt = Number(cnt)+1
			totDisbAmt = parseFloat(totDisbAmt) + parseFloat(disbAmt)
		}else{
			document.getElementById("finDisb"+String(counter)+"1").style.visibility = 'hidden'
			document.getElementById("finDisb"+String(counter)+"2").style.visibility = 'hidden'
			document.getElementById("finDisb"+String(counter)+"3").style.visibility = 'hidden'
			document.getElementById("finDisb"+String(counter)+"4").style.visibility = 'hidden'
			document.getElementById(String(counter)).style.visibility = 'hidden'
		}
		if(funcCode !="M"){
			document.getElementById("finDisb"+String(counter)+"4").disabled = true
		}else{
			document.getElementById("finDisb"+String(counter)+"4").disabled = false
		}

		counter+=1;
	}
	document.getElementById("noRec").value =cnt
	document.getElementById("cCode").value =cnt
	//alert(denomMainVal0)
	var totDisbAmtComma = totDisbAmt.toFixed(2).toString().replace(/\B(?=(\d{3})+\b)/g, ",")
	document.getElementById("indAmtVal").value = totDisbAmtComma;
	document.getElementById("disbAmt").value = totDisbAmt
	document.getElementById("DenomAmtCrncy").value = document.getElementById("crcnyCode").value; 
}


function denomSplitter(arg){
	//var value=arg.split("|")
	arr= arg.split(",");
	//denomNum= Number(arr[arr.length-1]);
	//alert(arg.split(',').length-1);
	denomNum=arg.split(',').length-1
	//alert(denomNum)
	len= arr.length-1;
	counter=1;
	var denomMainVal0=0;
	//alert(len)
	while (counter<=len){
		document.getElementById("Denom"+String(counter)+"1").value = "";
		document.getElementById("Denom"+String(counter)+"2").value = arr[counter].split("@")[0];
		document.getElementById("Denom"+String(counter)+"3").value = arr[counter].split("@")[1];
		document.getElementById("Denom"+String(counter)+"4").value = 0;
		document.getElementById("Denom"+String(counter)+"5").value = "0";
		document.getElementById("Denom"+String(counter)+"6").value = 0;
		//alert(arr[counter].split("@")[3])
		document.getElementById("Denom"+String(counter)+"7").value = arr[counter].split("@")[3];
		document.getElementById("Denom"+String(counter)+"8").value = arr[counter].split("@")[2];
		//alert(document.getElementById("Denom"+String(counter)+"8").value)
		//alert(document.getElementById("Denom"+String(counter)+"7").value)
		//alert(arr[counter].split("@")[3])
		document.getElementById("Denom"+String(counter)+"2").disabled = true
		document.getElementById("Denom"+String(counter)+"3").disabled = true
		document.getElementById("Denom"+String(counter)+"4").disabled = true
		var demonMainVal13 = document.getElementById("Denom"+String(counter)+"6").value
		//if(document.getElementById("Denom"+String(i)+"0").is(":checked")){
			//denomMainVal0 += parseFloat(demonMainVal13)
		//}
		counter+=1;
		//alert(counter);
	}
	
	document.getElementById("DenomAmt").value = 0;
	document.getElementById("DenomAmtCrncy").value = document.getElementById("crcnyCode").value; 
	
}
function fetchDepDetails(){

	var acctNo = document.getElementById("acctNo").value.toUpperCase();
	var funcCode = document.getElementById("funcCode").value.toUpperCase();
	
	document.getElementById("acctNo").value = acctNo;
	frm = document.forms[0]
	if (!(isNaN(acctNo)) && (acctNo.length > 10)){
		acctNo = formatAcct(acctNo);
	}
						
	if (!acctNo == ''){	
		
		var inputNameValues = "acctNum|"+acctNo+"|funcCode|"+funcCode;
		if(funcCode=="D"){
			var outputNames = "cifId|amt|AcctName|crcnyCode|disbdAmt|availDisbAmt|mnth|dayM|custType|msg";
		}else{
			var outputNames = "cifId|amt|AcctName|crcnyCode|totDisbAmts|disbdAmt|availDisbAmt|mnth|dayM|AD2|AD1|PNO|disbAmt|custType|msg";
		}
		var scrName ="simdisbmn004.scr";
		var retVal = appFnExecuteScript(inputNameValues,outputNames,scrName,true);   
		//alert("IN")
		if(document.getElementById("msg").value !=""){
			//alert("IN")
			alert(document.getElementById("msg").value)
			createTable(1);
			addTable(10)
			document.getElementById("msg").value =""
			document.getElementById("nfiu").value =""
			document.getElementById("totDisbAmts").disabled=true;
			return false;
		}
		custType = document.getElementById("custType").value
		//alert(document.getElementById("cifId").value)
		cifId = document.getElementById("cifId").value
		//alert(custType)
		//alert(document.getElementById("AD1").value)
		groNetDisb = document.getElementById("AD1").value
		finDisb = document.getElementById("AD2").value
		//alert(finDisb)
		tranType = document.getElementById("PNO").value
		//document.getElementById("disbAmt").focus()
		if(funcCode !="D"){
			//alert(finDisb)
			if(finDisb=="Y"){
				document.getElementById("finDisbYes").checked=true;
			}else{
				document.getElementById("finDisbNo").checked=true;
			}
			if(groNetDisb=="G"){
				document.getElementById("tranTypeGross").checked=true;
			}else{
				document.getElementById("tranTypeNet").checked=true;
			}
			if(tranType=="T"){
				document.getElementById("tranTypeTran").checked=true;
			}else{
				document.getElementById("tranTypeCash").checked=true;
			}
			//alert(cifId)
			custType = custType +cifId 
			//alert(custType)
			denomSplitter1(custType);
			disablerFeld();
		}else{
			document.getElementById("totDisbAmts").focus()
			document.getElementById("totDisbAmts").disabled=false;
		}
	}
}
function disablerFeld(){
	var funcCode = document.getElementById("funcCode").value.toUpperCase();
	if(funcCode !="M"){
		document.getElementById("tranTypeTran").disabled=true;
		document.getElementById("tranTypeCash").disabled=true;
		if(funcCode =="V"){
			//To enable and clear disbursement amount on verification
			document.getElementById("totDisbAmts").disabled=false;
			document.getElementById("hdisb").value = document.getElementById("totDisbAmts").value
			//document.getElementById("disbAmt").value = document.getElementById("totDisbAmts").value
			document.getElementById("totDisbAmts").value =""
			document.getElementById("disbAmt").value =""
			var nfiu = document.getElementById("nfiu").value
			for (i=1;i<=nfiu;i++){
				//document.getElementById("disbAmt").disabled=false;
				//alert()
				//alert()
				if(document.getElementById("finDisb"+String(i)+"2").value !=""){
					document.getElementById("finDisb"+String(i)+"2").disabled=false;
					document.getElementById("finDisb"+String(i)+"B").value = document.getElementById("finDisb"+String(i)+"2").value 
					document.getElementById("finDisb"+String(i)+"2").value =""
				}
			}
		}else{
			document.getElementById("totDisbAmts").disabled=true;
			
		}
		document.getElementById("disbAmt").disabled=true;
		document.getElementById("tranTypeGross").disabled=true;
		document.getElementById("tranTypeNet").disabled=true;
		document.getElementById("finDisbYes").disabled=true;
		document.getElementById("finDisbNo").disabled=true;
		document.getElementById("valDate").disabled=true;
		document.getElementById("Add").disabled=true;
		document.getElementById("firstName").disabled=true;
		document.getElementById("address1").disabled=true;
		//document.getElementById("totDisbAmts").disabled=true;
		document.getElementById("lastName").disabled=true;
		hideImage("acct1")
		
	}else{
		document.getElementById("tranTypeTran").disabled=false;
		document.getElementById("tranTypeCash").disabled=false;
		document.getElementById("disbAmt").disabled=false;
		document.getElementById("tranTypeGross").disabled=false;
		document.getElementById("tranTypeNet").disabled=false;
		document.getElementById("finDisbYes").disabled=false;
		document.getElementById("finDisbNo").disabled=false;
		document.getElementById("valDate").disabled=false;
		document.getElementById("Add").disabled=false;
		document.getElementById("address1").disabled=false;
		document.getElementById("firstName").disabled=false;
		document.getElementById("lastName").disabled=false;
		showImage("acct1")
	}
	
}


function fetchDepDetails1(obj){
	//alert("IN");
	var acctNo = document.getElementById("acctNo").value.toUpperCase();
	var disbAmt = document.getElementById("disbAmt").value;
	var hdisb = document.getElementById("hdisb").value;
	var funcCode = document.getElementById("funcCode").value.toUpperCase();
	var totDisbAmts = document.getElementById("totDisbAmts").value;
	var availDisbAmt = document.getElementById("availDisbAmt").value;
	document.getElementById("acctNo").value = acctNo;
	if(funcCode !="V"){
		if (!(isNaN(acctNo)) && (acctNo.length > 10)){
			acctNo = formatAcct(acctNo);
		}
		if(totDisbAmts !=""){
			if(parseFloat(totDisbAmts) > parseFloat(availDisbAmt)){
				alert("Total Amount to be disbursed is greter than Amount available for disbursement")
				document.getElementById("totDisbAmts").value =""
				document.getElementById("totDisbAmts").focus()
				return false;
			}
			//if(disbAmt ==""){
				//alert(obj.id)
			if(obj.id =="totDisbAmts"){
				document.getElementById("disbAmt").value = document.getElementById("totDisbAmts").value
				if(parseFloat(totDisbAmts) == parseFloat(availDisbAmt)){
					document.getElementById("finDisbYes").checked=true;
				}else{
					document.getElementById("finDisbNo").checked=true;
				}
			}
		}else{
			alert("Total Amount to be disbursed must be entered")
			document.getElementById("disbAmt").value =""
			document.getElementById("totDisbAmts").focus()
			return false;
		}	
		if (acctNo != ''){	
			var disbAmt = document.getElementById("disbAmt").value;
			var inputNameValues = "acctNum|"+acctNo+"|disbAmt|"+disbAmt;
			var outputNames = "cifId|amt|AcctName|crcnyCode|disbdAmt|availDisbAmt|mnth|dayM|custType|msg";
			var scrName ="simdisbmn001.scr";
			var retVal = appFnExecuteScript(inputNameValues,outputNames,scrName,true);
			custType = document.getElementById("custType").value
			cifId = document.getElementById("cifId").value
			
			//alert(cifId) 
			createTable(cifId);
			denomSplitter(custType);
			//fnNGN();
		}
	}else{
		//alert("NOW")
		document.getElementById("disbAmt").value = document.getElementById("totDisbAmts").value
		if(parseFloat(totDisbAmts) != parseFloat(hdisb)){
			alert("Entered total disbursement amount is not correct");
			document.getElementById("totDisbAmts").value="";
			document.getElementById("totDisbAmts").focus();
			return false
		}
	}
}
function fetchAcctDet(){

	var lastName = document.getElementById("lastName").value.toUpperCase();
	var disbAmt = document.getElementById("disbAmt").value;
	var crcnyCode = document.getElementById("crcnyCode").value;
	if(disbAmt ==""){
		alert("Enter disbursement amount")
		document.getElementById("disbAmt").focus()
		document.getElementById("lastName").value = ""
		return false;
	}
	document.getElementById("lastName").value = lastName;
	if (!(isNaN(lastName)) && (lastName.length > 10)){
		lastName = formatAcct(lastName);
	}
						
	if (!lastName == ''){	
		if (acctCheck == lastName)
		{
			return false;
		}else
		{
			acctCheck = lastName
		}
		var inputNameValues = "acctNum|"+lastName+"|crcnyCode|"+crcnyCode;
		var outputNames = "address1|msg";
		var scrName ="simdisbmn002.scr";
		var retVal = appFnExecuteScript(inputNameValues,outputNames,scrName,true);
		//custType = document.getElementById("custType").value
		msg = document.getElementById("msg").value
		if(msg !=""){
			alert(msg)
			document.getElementById("msg").value=""
			document.getElementById("lastName").value =""
			document.getElementById("address1").value =""
			document.getElementById("lastName").focus();
			return false;
		}else{
			document.getElementById("address1").disabled=true
		}
	}else{
		alert("Credit account cannot be empty");
		document.getElementById("lastName").focus();
		return false
	}
}

function calAmt(obj){
	//alert(obj.id)
	var denomMainVal0=0;
	var cifId = document.getElementById("cifId").value
	for (i=1;i<=cifId;i++){
		var demonMainVal1= document.getElementById("Denom"+String(i)+"5").value ;
		var demonVal15 = document.getElementById("Denom"+String(i)+"5").value;
		var checkbox = document.getElementById("Denom"+String(i)+"1")
		if(checkbox.checked){
			//alert(document.getElementById("Denom"+String(i)+"8").value)
			if(demonMainVal1==0){
				if(document.getElementById("Denom"+String(i)+"6").value != document.getElementById("Denom"+String(i)+"8").value ){
					if(document.getElementById("Denom"+String(i)+"6").value==0){
						if(i==1){
							document.getElementById("Denom"+String(i)+"6").value = document.getElementById("Denom"+String(i)+"8").value 
						}else{
							if(document.getElementById("Denom"+String(i-1)+"2").value == document.getElementById("Denom"+String(i)+"2").value ){
								if(document.getElementById("Denom"+String(i-1)+"5").value==0){
									document.getElementById("Denom"+String(i)+"6").value = document.getElementById("Denom"+String(i)+"8").value 
								}
							}else{
								document.getElementById("Denom"+String(i)+"6").value = document.getElementById("Denom"+String(i)+"8").value 
							}
						}
					}
					
				}else{
					
					document.getElementById("Denom"+String(i)+"6").value = document.getElementById("Denom"+String(i)+"8").value 
				}
				
				document.getElementById("Denom"+String(i)+"4").value = document.getElementById("Denom"+String(i)+"8").value 
				var demonVal16 = document.getElementById("Denom"+String(i)+"6").value ;
				denomMainVal0+=parseFloat(demonVal16)
			}else{
				var denomVall1 = document.getElementById("disbAmt").value
				denomVall2 = (parseFloat(demonMainVal1) * parseFloat(denomVall1))/100
				document.getElementById("Denom"+String(i)+"6").value = denomVall2
				if(i!=cifId){
					if(document.getElementById("Denom"+String(i+1)+"2").value == document.getElementById("Denom"+String(i)+"2").value ){
						document.getElementById("Denom"+String(i+1)+"6").value = denomVall2 * 0.05 
					}
				}
				denomMainVal0+=parseFloat(denomVall2)
			}
		}else{
			document.getElementById("Denom"+String(i)+"4").value = 0
			document.getElementById("Denom"+String(i)+"6").value = 0
			document.getElementById("Denom"+String(i)+"5").value = 0
		}
	}
	
	var denomComma = denomMainVal0.toFixed(2).toString().replace(/\B(?=(\d{3})+\b)/g, ",")
	document.getElementById("DenomAmt").value = denomComma;
	document.getElementById("DenomAmtCrncy").value = document.getElementById("crcnyCode").value; 
}
function delRecord(){
	var noRec = document.getElementById("noRec").value
	//alert(noRec)
	if(noRec==1){
		document.getElementById("nfiu").value=""
		document.getElementById("cCode").value=""
		document.getElementById("noRec").value=""
		document.getElementById("sal").value =""
		document.getElementById("AD1").value =""
		//var nfiu =""
		//alert(document.getElementById("nfiu").value)
		addTable(10);
		
	}else{
		//check for number of records selected to be deleted and mark them as delete
		j=0   //initiatlizing no of record to delete
		p=0   //initializing no of record selected
		var nfiu = document.getElementById("nfiu").value
		//alert(nfiu)
		for (i=1;i<=nfiu;i++){
			var checkbox = document.getElementById("finDisb"+String(i)+"4")
			//alert(checkbox.checked)
			if(checkbox.checked){
				p=p+1
				//alert("checked")
				//alert("finDisb"+String(i)+"A")
				var delRecval= document.getElementById("finDisb"+String(i)+"A").value
				//alert(delRecval)
				
				for (k=1;k<=nfiu;k++){
					//alert(i)
					//alert(document.getElementById("finDisb"+String(k)+"A").value)
					if(document.getElementById("finDisb"+String(k)+"A").value == i){
						//alert("finDisb"+String(k)+"A")
						j=j+1
						document.getElementById("finDisb"+String(k)+"A").value ="Y"
						
					}
				}
				document.getElementById("finDisb"+String(i)+"1").value =""
				document.getElementById("finDisb"+String(i)+"2").value =""
				document.getElementById("finDisb"+String(i)+"3").value =""
			}
		}
		//alert(j)
		//alert(nfiu)
		if(Number(noRec)==p){
			//alert("IN1")
			document.getElementById("nfiu").value=""
			document.getElementById("cCode").value=""
			document.getElementById("noRec").value=""
			document.getElementById("sal").value =""
			document.getElementById("AD1").value =""
			//var nfiu =""
			//alert(document.getElementById("nfiu").value)
			addTable(10); //remove all records if ll record are selected
			return true
		}else{
			var len = Number(nfiu)-j //subtract record to be deleted from total number of record
			//alert("IN")
			//alert(len)
			if(len==0){//refresh record number if all record was deleted
				document.getElementById("nfiu").value=""
				document.getElementById("cCode").value=""
				document.getElementById("noRec").value=""
				document.getElementById("sal").value =""
				document.getElementById("AD1").value =""
				//var nfiu =""	
				//alert("Yes")
				addTable(10); 
				return true
			}
			remRecTable(len)
			cCode = document.getElementById("cCode").value
			//alert("here")
			//alert(cCode)
			//alert(p)
			cCode = Number(cCode)-p
			//alert(cCode)
			document.getElementById("cCode").value = cCode
			document.getElementById("noRec").value = cCode
			document.getElementById("sal").value = cCode*10
		}
	}
}

function checkCredAmt(){
	var nfiu = document.getElementById("nfiu").value
	for (i=1;i<=nfiu;i++){
		if(document.getElementById("finDisb"+String(i)+"2").value != document.getElementById("finDisb"+String(i)+"B").value){
			if(document.getElementById("finDisb"+String(i)+"2").value !=""){
				alert("Credit amount entered is invalid for the account") 
				document.getElementById("finDisb"+String(i)+"2").value =""
			}
		}
	}
}
function fetchRecMod(obj){
	var funcCode = document.getElementById("funcCode").value.toUpperCase();
	//alert(obj.id)
	var acctNum=""
	if(funcCode !="V"){
		var nfiu = document.getElementById("nfiu").value
		//alert(nfiu)
		for (k=1;k<=nfiu;k++){
			if(k == obj.id){
				
				document.getElementById("disbAmt").value = document.getElementById("finDisb"+String(k)+"2").value ;
				document.getElementById("disbAmt").onchange();
				document.getElementById("lastname").value = document.getElementById("finDisb"+String(k)+"1").value ;
				//document.getElementById("address1").value = document.getElementById("finDisb"+String(k)+"6").value ;
				document.getElementById("address2").value = document.getElementById("finDisb"+String(k)+"2").value ;
				acctNum=document.getElementById("finDisb"+String(k)+"1").value 
				document.getElementById("finDisb"+String(k)+"4").checked=true
			}
			if(document.getElementById("finDisb"+String(k)+"5").value == acctNum){
				document.getElementById("address1").value = document.getElementById("finDisb"+String(k)+"6").value 
			}
			if(document.getElementById("address1").value != ""){
				//alert("Oya")
				delRecord()
			}
		}
		
	}
}
function takeRec(obj){
	if(obj.id=="checkAll1"){
		//alert("IN")
		if(obj.checked==true){
			var nfiu = document.getElementById("nfiu").value
			for (i=1;i<=nfiu;i++){
				if(document.getElementById("finDisb"+String(i)+"2").value != ""){
					if(document.getElementById("finDisb"+String(i)+"2").value !=""){
						document.getElementById("finDisb"+String(i)+"4").checked=true 
					}
				}
			}
		}else{
			var nfiu = document.getElementById("nfiu").value
			for (i=1;i<=nfiu;i++){
				if(document.getElementById("finDisb"+String(i)+"2").value != ""){
					if(document.getElementById("finDisb"+String(i)+"2").value !=""){
						document.getElementById("finDisb"+String(i)+"4").checked=false 
					}
				}
			}
		}
		return true
	}
}
function addRecord(){
	cifId = document.getElementById("cifId").value
	var funcCode = document.getElementById("funcCode").value.toUpperCase();
	k=0
	for (i=1;i<=cifId;i++){
		//alert(document.getElementById("Denom"+String(i)+"1").checked);
		if (document.getElementById("Denom"+String(i)+"1").checked) {
			k=k+1
		}
	}
	if(k==0){
		//alert("You've not selected ")
		var conf = confirm("Charges not selected!!!! Customer wont be charged, do you want to continue? ")
		if (conf==true){
			
		}
		else{
			return false;
		}

	}
	var lastName = document.getElementById("lastName").value.toUpperCase();
	var address2 = document.getElementById("address2").value;
	if(lastName ==""){
		alert("Credit account must be Entered!!!");
		document.getElementById("lastName").focus();
		return false
	}
	if(address2 ==""){
		alert("Credit Amount must be Entered!!!");
		document.getElementById("address2").focus();
		return false
	}
	//check if Total disbursement is greater than Amount specified for disbursement
	var availDisbAmt =document.getElementById("availDisbAmt").value
	if(availDisbAmt ==""){
		availDisbAmt=0
	}
	
	numbs1=document.getElementById("nfiu").value 
	//alert(numbs1)
	if(funcCode=="M"){
		numbs1 = Number(numbs1)-1
	}
	if(numbs1 !=""){
		totDisbAmt =0
		for (i=1;i<=numbs1;i++){
			//alert("finDisb"+String(i)+"2")
			//alert(document.getElementById("finDisb"+String(i)+"2").value)
			if (document.getElementById("finDisb"+String(i)+"2").value !="") {
				var disbAmount = document.getElementById("finDisb"+String(i)+"2").value
				var totDisbAmt = parseFloat(totDisbAmt) +  parseFloat(disbAmount)
				//alert(totDisbAmt)
			}
		}
		var address2 = document.getElementById("address2").value
		var totDisbAmt = parseFloat(totDisbAmt) + parseFloat(address2) 
	}else{
		var totDisbAmt = document.getElementById("address2").value
		totDisbAmt = parseFloat(totDisbAmt)
	}
	//alert(totDisbAmt)
	if(parseFloat(totDisbAmt) > parseFloat(availDisbAmt)){
		alert("Total Amount disbursed is greater than Disbursement Amtount")
		document.getElementById("disbAmt").focus()
		return false;
	}
	
	var sal = document.getElementById("sal").value 
	var cCode = document.getElementById("cCode").value 
	var noRec = document.getElementById("noRec").value 
	var numbs = Number(sal)+10	
	var numbs1 = Number(cCode)+1
	
	
	//alert(numbs)
	document.getElementById("sal").value = numbs
	document.getElementById("cCode").value = numbs1
	//alert("IN")
	if(noRec ==""){
		noRec = 1
		document.getElementById("noRec").value  = noRec
	}else{
		noRec = Number(noRec)+1
		document.getElementById("noRec").value  = noRec
	}
	//alert(document.getElementById("nfiu").value)
	if(document.getElementById("nfiu").value==""){
		//alert("IN1")
		//alert(numbs1)
		//var numbs1 = k+1
		addeTable(noRec,numbs1);
		numbs2=k+1
		//alert(numbs2)
		addAcctEnt(numbs1,numbs2);
	}else{
		//alert("IN2")
		var nfiu = document.getElementById("nfiu").value
		numbs1 =  Number(nfiu) ;
		/*if(funcCode=="M"){
			numbs1 = Number(numbs1)-1
		}*/
		document.getElementById("nfiu").value =numbs1
		//alert(k)
		document.getElementById("AD1").value =k*2
		//alert(numbs1)
		addeTable(noRec,numbs1);
		//numbs2=1+numbs1;
		//addAcctEnt(numbs1,numbs2);
	}
	
	
	//Calculate Total disbursement
	//alert(totDisbAmt)
	var totDisbAmtComma = totDisbAmt.toFixed(2).toString().replace(/\B(?=(\d{3})+\b)/g, ",")
	document.getElementById("indAmtVal").value = totDisbAmtComma
	document.getElementById("DenomAmtCrncy").value = document.getElementById("crcnyCode").value;
	var availDisbAmt = document.getElementById("availDisbAmt").value
	if(availDisbAmt==""){
		availDisbAmt=0
	}
	
	//Clear data
	document.getElementById("address2").value=""
	document.getElementById("lastName").value=""
	document.getElementById("address1").value=""
	document.getElementById("disbAmt").value=""
	
}

function createTable(num){

	var tbody="<table border=0>";
	var id=11;
	//alert(num)
	var address1 =""
	var lastName =""
	if (document.getElementById("lastName")) {
		if(document.getElementById("lastName").value !=""){
			 lastName = document.getElementById("lastName").value
		}
		if(document.getElementById("address1").value !=""){
			address1 = document.getElementById("address1").value
		}
	}
	
	for (i=1;i<=num;i++){
		
		if (i==1){
			tbody+='<tr>';
			tbody+='<td style="width: 20px;">';
			//tbody+='<input type="text"  name="'+ subGroupName + '.Denom11" id="Denom11" '+ simdisbProps.get("Denom11_ENABLED") + ' style="text-align:right;width: 117px;border:0px;background-color:white">';
			tbody+='<input type="checkbox" name="Denom11" id="Denom11" onchange="calAmt(this)" onkeyup="calAmt(this)" onmousedown="calAmt(this)" onfocus="calAmt(this)" onblur="calAmt()" >'; 
			tbody+='</td>';
			tbody+='<td>';
			tbody+='<input type="text" onkeyup="MonitorKeyPress2(12)" onmousedown="rmZero2(12)"  class="textfieldfont" name="'+ subGroupName + '.Denom12" id="Denom12" ' + simdisbProps.get("Denom12_ENABLED") + ' style="text-align:left;width: 100px" onblur="calAmt()">';
			tbody+='</td>';
			tbody+='<td>'; 
			tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.Denom13" id="Denom13" '+ simdisbProps.get("Denom13_ENABLED") + ' style="text-align:left;width: 150px">';
			tbody+='</td>';
			tbody+='<td></td>';
			tbody+='<td>';
			tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.Denom14" id="Denom14" '+ simdisbProps.get("Denom14_ENABLED") + ' style="text-align:right;width: 100px">';
			tbody+='</td>';
			tbody+='<td> ';
			tbody+='<input type="text" class="textfieldfont"  onblur="calAmt()" name="'+ subGroupName + '.Denom15" id="Denom15" '+ simdisbProps.get("Denom15_ENABLED") + ' style="text-align:right;width: 100px" >';
			tbody+='</td>';
			tbody+='<td>'; 
			tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.Denom16" id="Denom16" ' + simdisbProps.get("Denom16_ENABLED") + ' style="text-align:right;width: 100px">';
			tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.Denom17" id="Denom17" ' + simdisbProps.get("Denom17_ENABLED") + ' style="text-align:right;width: 100px">';
			tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.Denom18" id="Denom18" ' + simdisbProps.get("Denom18_ENABLED") + ' style="text-align:right;width: 100px">';
			tbody+='</td>';
			tbody+='<td rowspan="13"> ';
			tbody+='<table align="top" border="1"cellspacing="0" style="border-width:0 0 0 0;">';
					tbody+='<tr>';

			tbody+='<td>';
							tbody+='<table align="top">';
					
			tbody+='<tr>';
			tbody+='<td class="textlabel" colspan="2" style="width: 150px" >'+ "Mode of Disbursement" + '</td>';
			tbody+='<td class="textfield">';  
			//tbody+='<input type="text" class="textfieldfont" name="firstName" id="firstName" style="width: 135px">'; 
			tbody+='<select style="height: 15px ; width: 200px" name="firstName" id="firstName" onChange="javascript:return onChangeFunnccode();" >';
			tbody+='<option value="T" id="T">' + "A – A/C. Transfer" + '</option>';
			//tbody+='<option value="M" id="M">' + "M-MODIFY" + '</option>';
			//tbody+='<option value="X" id="X">' + "X-DELETE" + '</option>';
			tbody+='</select>';
			tbody+='</td>'; 
			tbody+='</tr>';
			tbody+='<tr>';
			tbody+='<td class="textlabel" colspan="2">'+ "Credit Acc. No" + '</td>';  
			tbody+='<td class="textfield">';   
			tbody+='<input type="text" class="textfieldfont" name="lastName" id="lastname" style="width: 200px" onblur="fetchAcctDet()">';
			tbody+='&nbsp;<a href="javascript:showAccountIdList(document.forms[0].lastName);document.getElementById(\'lastName\').onchange();">';
			tbody+='<img id="acct1" border="0" height="17" hotKeyId="search1" src="../Renderer/images/'+applangcode+'/search_icon.gif" width="16">';
			tbody+='</a>';
			tbody+='</td>';
			tbody+='</tr>';

			tbody+='<tr>';
			tbody+='<td class="textlabel" colspan="2">'+ "" + '</td>';  
			tbody+='<td class="textfield"  >';  
			tbody+='<input type="text" class="textfieldfont" name="address1" id="address1" style="width: 200px">';  
			tbody+='</td>'; 
			tbody+='</tr>';
			tbody+='<tr>';
			tbody+='<td class="textlabel" colspan="2">'+ "Credit Amt." + '</td>';  
			tbody+='<td class="textfield" >';  
			tbody+='<input type="text" class="textfieldfont" name="address2" id="address2" style="width: 200px">';  
			tbody+='</td>';
			tbody+='</tr>';
			tbody+='<tr>';
			tbody+='<td class="textlabel" colspan="2">'+ "" + '</td>';  
			tbody+='<td class="textfield" >';  
			tbody+='<td >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>'
			//tbody+='<input type="text" class="textfieldfont" name="address2" id="address2" style="width: 150px">';  
			tbody+='</td>';
			tbody+='</tr>';
			tbody+='<tr>';
			tbody+='<td class="textlabel" colspan="2">' + "" + '</td>';  
			tbody+='<td class="textfield" align="center">';  
			//tbody+='<input type="text" class="textfieldfont" name="phoneNo" id="phoneNo" style="width: 135px">';  
			tbody+='<input id="Add" name="Add" type="button" class="button"	onClick="javascript:return addRecord();"" value="Add" hotKeyId="Add">';
			tbody+='</td>'; 
			tbody+='</tr>';
			tbody+='<tr>';
			tbody+='<td>&nbsp; &nbsp;&nbsp;&nbsp;</td>';  
			tbody+='<td class="textfield">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'; 
			tbody+='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'; 
			tbody+='</td>';
			tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
			tbody+='</tr>';
					

					tbody+='</table>';
					
					tbody+='</td>';
					tbody+='</tr>';


			tbody+='</table>';
			tbody+='</td>';
			tbody+='</tr>';
			

		}
	

		else
		{

			id+=10
			
			tbody+='<tr>';

			tbody+='<td>';
			//tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.Denom'+ String(id)+'" id="Denom'+ String(id)+'" ' + simdisbProps.get("Denom"+ String(id)+"_ENABLED") + ' style="text-align:right;border:0px;background-color:white;width: 117px" value="500">';
			tbody+='<input type="checkbox" onchange="calAmt(this)" onkeyup="calAmt(this)" onmousedown="calAmt(this)" onfocus="calAmt(this)" onblur="calAmt()" name="'+ subGroupName + '.Denom'+ String(id)+'" id="Denom'+ String(id)+'" ' + simdisbProps.get("Denom"+ String(id)+"_ENABLED") + '>';
			tbody+='</td>';
			tbody+='<td >'; 
			var a='<input type="text"  class="textfieldfont" name="' + subGroupName + '.Denom'+ String(id+1)+'" id="Denom'+ String(id+1)+'" ' + simdisbProps.get("Denom"+ String(id+1)+"_ENABLED") + ' style="text-align:left;width: 100px" onblur="calAmt()">';
			tbody+=a;
			
			tbody+='</td>';
			tbody+='<td> ';
			tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.Denom'+ String(id+2)+'" id="Denom'+ String(id+2)+'" ' + simdisbProps.get("Denom"+ String(id+2)+"_ENABLED") + ' style="text-align:left;width: 150px" >';
			tbody+='</td>';
			tbody+='<td></td>';
			tbody+='<td>';
			tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.Denom'+ String(id+3)+'" id="Denom'+ String(id+3)+'" ' + simdisbProps.get("Denom"+ String(id+3)+"_ENABLED") + ' style="text-align:right;width: 100px" value="10">';
			tbody+='</td>';
			tbody+='<td> ';
			tbody+='<input type="text" class="textfieldfont"   onblur="calAmt()" name="' + subGroupName + '.Denom'+ String(id+4)+'" id="Denom'+ String(id+4)+'" ' + simdisbProps.get("Denom"+ String(id+4)+"_ENABLED") + ' style="text-align:right;width: 100px" >';
			tbody+='</td>';
			tbody+='<td>'; 
			tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.Denom'+ String(id+5)+'" id="Denom'+ String(id+5)+'" ' + simdisbProps.get("Denom"+ String(id+5)+"_ENABLED") + ' style="text-align:right;width: 100px" >';
			//alert(String(id+6))
			tbody+='<input type="hidden" class="textfieldfont" name="' + subGroupName + '.Denom'+ String(id+6)+'" id="Denom'+ String(id+6)+'" ' + simdisbProps.get("Denom"+ String(id+6)+"_ENABLED") + ' style="text-align:right;width: 100px" >';
			tbody+='<input type="hidden" class="textfieldfont" name="' + subGroupName + '.Denom'+ String(id+7)+'" id="Denom'+ String(id+7)+'" ' + simdisbProps.get("Denom"+ String(id+7)+"_ENABLED") + ' style="text-align:right;width: 100px" >';
			tbody+='<input type="hidden" class="textfieldfont" name="' + subGroupName + '.Denom'+ String(id+8)+'" id="Denom'+ String(id+8)+'" ' + simdisbProps.get("Denom"+ String(id+8)+"_ENABLED") + ' style="text-align:right;width: 100px" >';
			tbody+='</td>';
			tbody+='</tr>';
			

		}
		
	}
	tbody+='<tr>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ' + jspResArr.get("FLT00018") + '';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.DenomAmt" id="DenomAmt" ' + simdisbProps.get("DenomAmt_ENABLED") + ' style="border:0px;background-color:white;width:117px">';
	tbody+='</td>';
	tbody+='<td>';
	
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.DenomAmtCrncy" id="DenomAmtCrncy" ' + simdisbProps.get("DenomAmtCrncy_ENABLED") + ' style="border:0px;background-color:white;width: 30px;border:0px">';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ';
	tbody+='</td>';
	tbody+='</tr>';	
	tbody+='</table>'
	
	document.getElementById("denomTable").tBodies[0].setAttribute("id","tableGenerate");
	body=document.getElementById("tableGenerate");
	var temp = body.ownerDocument.createElement("div");

	temp.innerHTML=tbody;
	body.parentNode.replaceChild(temp.firstChild.firstChild, body);
	
	//Assign value to disbursement value to credit Amount
	document.getElementById("address2").value = document.getElementById("disbAmt").value	
	if (document.getElementById("lastName")) {
		document.getElementById("lastName").value = lastName	
		document.getElementById("address1").value = address1
		//alert(document.getElementById("address2").value)
	}
	document.getElementById("address2").disabled=true;
	
}
function addTablev(numbs){
	var tbody="<table border=0>";
	//var id=11;
	//alert(numbs)
	id=10
	for (i=1;i<=numbs;i++){
		tbody+='<tr id="101">';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<img  alt="Modify Record" id="'+ String(i)+'" border="0" height="17" hotKeyId="search1" src="../Renderer/images/'+applangcode+'/explode.gif" width="16" onclick="javascript:fetchRecMod(this);" >';
		tbody+='<input type="text"  class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+1)+'" id="finDisb'+ String(id+1)+'" '+ simdisbProps.get("finDisb"+ String(id+1)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+2)+'" id="finDisb'+ String(id+2)+'" '+ simdisbProps.get("finDisb"+ String(id+2)+"_ENABLED") + ' style="text-align:right;width: 100px" onChange="javascript:return checkCredAmt();"  >';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+3)+'" id="finDisb'+ String(id+3)+'" '+ simdisbProps.get("finDisb"+ String(id+3)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">&nbsp;';
		tbody+='<input type="checkbox" name="finDisb'+ String(id+4)+'" id="finDisb'+ String(id+4)+'">';
		tbody+='</td>';
		tbody+='<td >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+5)+'" id="finDisb'+ String(id+5)+'" '+ simdisbProps.get("finDisb"+ String(id+5)+"_ENABLED") + ' style="text-align:left;width: 120px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+6)+'" id="finDisb'+ String(id+6)+'" '+ simdisbProps.get("finDisb"+ String(id+6)+"_ENABLED") + ' style="text-align:left;width: 200px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+7)+'" id="finDisb'+ String(id+7)+'" '+ simdisbProps.get("finDisb"+ String(id+7)+"_ENABLED") + ' style="text-align:right;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+8)+'" id="finDisb'+ String(id+8)+'" '+ simdisbProps.get("finDisb"+ String(id+8)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+9)+'" id="finDisb'+ String(id+9)+'" '+ simdisbProps.get("finDisb"+ String(id+9)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(i)+'A" id="finDisb'+ String(i)+'A" '+ simdisbProps.get("finDisb"+ String(i)+"A_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(i)+'B" id="finDisb'+ String(i)+'B" '+ simdisbProps.get("finDisb"+ String(i)+"B_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		//tbody+='<span style="color:red">  *</span></td>';
		tbody+='</tr>';
		id+=10;
	}
	tbody+='<tr>';
	tbody+='<td>&nbsp; &nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td class="textlabel" >' + "" + '</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  	
	tbody+='<td class="textfield" align="center">';  
	//tbody+='<input type="text" class="textfieldfont" name="phoneNo" id="phoneNo" style="width: 135px">';  
	tbody+='<input id="Del" name="Del" type="button" class="button"	onClick="javascript:return delRecord();"" value="Del" hotKeyId="Del">';
	tbody+='</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='</tr>';
		
		tbody+='<tr>';
		tbody+='<td>';
		tbody+='</td>';
		tbody+='<td> ' + "Total Disbursed" + '';
		tbody+='</td>';
		tbody+='<td>'; 
		tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.indAmtVal" id="indAmtVal" ' + simdisbProps.get("indAmtVal_ENABLED") + ' style="border:0px;background-color:white;width:117px">';
		tbody+='</td>';
		tbody+='<td>';
		tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.DenomAmtCrncy" id="DenomAmtCrncy" ' + simdisbProps.get("DenomAmtCrncy_ENABLED") + ' style="border:0px;background-color:white;width: 30px;border:0px">';
		tbody+='</td>';
		tbody+='<td>'; 
		tbody+='</td>';
		tbody+='<td>';
		tbody+='</td>';
		tbody+='<td>';
		tbody+='</td>';
		tbody+='<td> ';
		tbody+='</td>';
		tbody+='</tr>';	
		tbody+='</table>'
	document.getElementById("sumTable").tBodies[0].setAttribute("id","tableSumGen");
	body=document.getElementById("tableSumGen");
	var temp = body.ownerDocument.createElement("div");

	temp.innerHTML=tbody;
	body.parentNode.replaceChild(temp.firstChild.firstChild, body);
	
	//alert("done")
	
	
}

function addTable(numbs){
	var tbody="<table border=0>";
	//var id=11;
	//alert(numbs)
	document.getElementById("nfiu").value=""
	id=numbs
	tbody+='<tr>';
	//tbody+='<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090216") + "";
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<img  alt="Modify Record" id="'+ String(1)+'" border="0" height="17" hotKeyId="search1" src="../Renderer/images/'+applangcode+'/explode.gif" width="16" onclick="javascript:fetchRecMod(this);" >';
	tbody+='<input type="text"  class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+1)+'" id="finDisb'+ String(id+1)+'" '+ simdisbProps.get("finDisb"+ String(id+1)+"_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+2)+'" id="finDisb'+ String(id+2)+'" '+ simdisbProps.get("finDisb"+ String(id+2)+"_ENABLED") + ' style="text-align:right;width: 100px" onChange="javascript:return checkCredAmt();"  >';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+3)+'" id="finDisb'+ String(id+3)+'" '+ simdisbProps.get("finDisb"+ String(id+3)+"_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">&nbsp;';
	tbody+='<input type="checkbox" name="finDisb'+ String(id+4)+'" id="finDisb'+ String(id+4)+'">';
	tbody+='</td>';
	tbody+='<td >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+5)+'" id="finDisb'+ String(id+5)+'" '+ simdisbProps.get("finDisb"+ String(id+5)+"_ENABLED") + ' style="text-align:left;width: 120px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+6)+'" id="finDisb'+ String(id+6)+'" '+ simdisbProps.get("finDisb"+ String(id+6)+"_ENABLED") + ' style="text-align:left;width: 200px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+7)+'" id="finDisb'+ String(id+7)+'" '+ simdisbProps.get("finDisb"+ String(id+7)+"_ENABLED") + ' style="text-align:right;width: 100px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+8)+'" id="finDisb'+ String(id+8)+'" '+ simdisbProps.get("finDisb"+ String(id+8)+"_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+9)+'" id="finDisb'+ String(id+9)+'" '+ simdisbProps.get("finDisb"+ String(id+9)+"_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(1)+'A" id="finDisb'+ String(1)+'A" '+ simdisbProps.get("finDisb"+ String(1)+"A_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(1)+'B" id="finDisb'+ String(1)+'B" '+ simdisbProps.get("finDisb"+ String(1)+"B_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='</td>';
	//tbody+='<span style="color:red">  *</span></td>';
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td>&nbsp; &nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td class="textlabel" >' + "" + '</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  	
	tbody+='<td class="textfield" align="center">';  
	//tbody+='<input type="text" class="textfieldfont" name="phoneNo" id="phoneNo" style="width: 135px">';  
	tbody+='<input id="Del" name="Del" type="button" class="button"	onClick="javascript:return delRecord();"" value="Del" hotKeyId="Del">';
	tbody+='</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='</tr>';
	
	
	tbody+='<tr>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ' + "Total Disbursed" + '';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.indAmtVal" id="indAmtVal" ' + simdisbProps.get("indAmtVal_ENABLED") + ' style="border:0px;background-color:white;width:117px">';
	tbody+='</td>';
	tbody+='<td>';
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.DenomAmtCrncy" id="DenomAmtCrncy" ' + simdisbProps.get("DenomAmtCrncy_ENABLED") + ' style="border:0px;background-color:white;width: 30px;border:0px">';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ';
	tbody+='</td>';
	tbody+='</tr>';	
	tbody+='</table>'
	document.getElementById("sumTable").tBodies[0].setAttribute("id","tableSumGen");
	body=document.getElementById("tableSumGen");
	var temp = body.ownerDocument.createElement("div");

	temp.innerHTML=tbody;
	body.parentNode.replaceChild(temp.firstChild.firstChild, body);
	
	//alert("done")
}

function addAcctEnt(numbs1,numbs2){
	
	//var numbs1=numbs2
	var noRec = document.getElementById("noRec").value 
	//alert(noRec)
	var arr1 = new Array();
	var arr2 = new Array();
	var arr3 = new Array();
	var arr4 = new Array();
	var arr5 = new Array();
	var arr6 = new Array();
	var arr7 = new Array();
	var arr8 = new Array();
	//alert(num)
	//var id=11;
	//alert(numbs2)
	//alert("IN")
	for (i=1;i<=numbs1;i++){
		//alert("finDisb"+String(i)+"1")
		//alert(document.getElementById("finDisb"+String(i)+"1").value)
		arr1[i] = document.getElementById("finDisb"+String(i)+"1").value ;
		//alert(arr1[i]);
		arr2[i] = document.getElementById("finDisb"+String(i)+"2").value ;
		arr3[i] = document.getElementById("finDisb"+String(i)+"3").value ;
		arr4[i] = document.getElementById("finDisb"+String(i)+"5").value ;
		arr5[i] = document.getElementById("finDisb"+String(i)+"6").value ;
		arr6[i] = document.getElementById("finDisb"+String(i)+"7").value ;
		arr7[i] = document.getElementById("finDisb"+String(i)+"8").value ;
		arr8[i] = document.getElementById("finDisb"+String(i)+"A").value ;
	}
	
	var tbody="<table border=0>";
	//cifId = document.getElementById("cifId").value
	if(document.getElementById("nfiu").value==""){
		numbs1 = Number(numbs2)*2;
	}else{
		k=document.getElementById("sal").value;
		k=Number(k)*2;
		numbs1 = numbs2+k;
	}
	//alert(cifId)
	var id=10;
	tbody+='<tr id="101">';
	//tbody+='<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090216") + "";
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<img  alt="Modify Record" id="'+ String(1)+'" border="0" height="17" hotKeyId="search1" src="../Renderer/images/'+applangcode+'/explode.gif" width="16" onclick="javascript:fetchRecMod(this);" >';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+1)+'" id="finDisb'+ String(id+1)+'" '+ simdisbProps.get("finDisb"+ String(id+1)+"_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+2)+'" id="finDisb'+ String(id+2)+'" '+ simdisbProps.get("finDisb"+ String(id+2)+"_ENABLED") + ' style="text-align:right;width: 100px" onChange="javascript:return checkCredAmt();" >';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+3)+'" id="finDisb'+ String(id+3)+'" '+ simdisbProps.get("finDisb"+ String(id+3)+"_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">&nbsp;';
	tbody+='<input type="checkbox" name="finDisb'+ String(id+4)+'" id="finDisb'+ String(id+4)+'" >';
	tbody+='</td>';
	tbody+='<td >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+5)+'" id="finDisb'+ String(id+5)+'" '+ simdisbProps.get("finDisb"+ String(id+5)+"_ENABLED") + ' style="text-align:left;width: 120px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+6)+'" id="finDisb'+ String(id+6)+'" '+ simdisbProps.get("finDisb"+ String(id+6)+"_ENABLED") + ' style="text-align:left;width: 200px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+7)+'" id="finDisb'+ String(id+7)+'" '+ simdisbProps.get("finDisb"+ String(id+7)+"_ENABLED") + ' style="text-align:right;width: 100px">';
	tbody+='</td>';
	tbody+='<td class="textfield" style="width: 117px">';
	tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+8)+'" id="finDisb'+ String(id+8)+'" '+ simdisbProps.get("finDisb"+ String(id+8)+"_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+9)+'" id="finDisb'+ String(id+9)+'" '+ simdisbProps.get("finDisb"+ String(id+9)+"_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(1)+'A" id="finDisb'+ String(1)+'A" '+ simdisbProps.get("finDisb"+ String(1)+"A_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(1)+'B" id="finDisb'+ String(1)+'B" '+ simdisbProps.get("finDisb"+ String(1)+"B_ENABLED") + ' style="text-align:left;width: 100px">';
	tbody+='</td>';
	//tbody+='<span style="color:red">  *</span></td>';
	tbody+='</tr>';
	//alert(numbs1)
	if(document.getElementById("nfiu").value==""){
		document.getElementById("nfiu").value=1
	}
	for (i=1;i<numbs1;i++){
		//alert("Denom"+String(i)+"1");
		//alert(document.getElementById("Denom"+String(i)+"1").checked);
		//if (document.getElementById("Denom"+String(i)+"1").checked) {
				
			var nfiu = document.getElementById("nfiu").value
			nfiu = Number(nfiu)+1
			document.getElementById("nfiu").value = nfiu
			
			id+=10
			//alert(String(id+1))
			tbody+='<tr>';
			//tbody+='<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090216") + "";
			tbody+='<td class="textfield" style="width: 117px">';
			//tbody+='<img  alt="Modify Record" id="'+ String(i+1)+'" border="0" height="17" hotKeyId="search1" src="../Renderer/images/'+applangcode+'/explode.gif" width="16" onclick="javascript:fetchRecMod(this);" >';
			tbody+='<input type="hidden"  class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+1)+'" id="finDisb'+ String(id+1)+'" '+ simdisbProps.get("finDisb"+ String(id+1)+"_ENABLED") + ' style="text-align:left;width: 100px">';
			tbody+='</td>';
			tbody+='<td class="textfield" style="width: 117px">';
			tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+2)+'" id="finDisb'+ String(id+2)+'" '+ simdisbProps.get("finDisb"+ String(id+2)+"_ENABLED") + ' style="text-align:right;width: 100px" onChange="javascript:return checkCredAmt();" >';
			tbody+='</td>';
			tbody+='<td class="textfield" style="width: 117px">';
			tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+3)+'" id="finDisb'+ String(id+3)+'" '+ simdisbProps.get("finDisb"+ String(id+3)+"_ENABLED") + ' style="text-align:left;width: 100px">';
			tbody+='</td>';
			tbody+='<td class="textfield" style="width: 117px">&nbsp;';
			tbody+='<input type="hidden" name="finDisb'+ String(id+4)+'" id="finDisb'+ String(id+4)+'" >';
			tbody+='</td>';
			tbody+='<td >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
			tbody+='<td class="textfield" style="width: 117px">';
			tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+5)+'" id="finDisb'+ String(id+5)+'" '+ simdisbProps.get("finDisb"+ String(id+5)+"_ENABLED") + ' style="text-align:left;width: 120px">';
			tbody+='</td>';
			tbody+='<td class="textfield" style="width: 117px">';
			tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+6)+'" id="finDisb'+ String(id+6)+'" '+ simdisbProps.get("finDisb"+ String(id+6)+"_ENABLED") + ' style="text-align:left;width: 200px">';
			tbody+='</td>';
			tbody+='<td class="textfield" style="width: 117px">';
			tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+7)+'" id="finDisb'+ String(id+7)+'" '+ simdisbProps.get("finDisb"+ String(id+7)+"_ENABLED") + ' style="text-align:right;width: 100px">';
			tbody+='</td>';
			tbody+='<td class="textfield" style="width: 117px">';
			tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+8)+'" id="finDisb'+ String(id+8)+'" '+ simdisbProps.get("finDisb"+ String(id+8)+"_ENABLED") + ' style="text-align:left;width: 100px">';
			tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+9)+'" id="finDisb'+ String(id+9)+'" '+ simdisbProps.get("finDisb"+ String(id+9)+"_ENABLED") + ' style="text-align:left;width: 100px">';
			//alert("finDisb"+ String(i+1)+"A")
			tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(i+1)+'A" id="finDisb'+ String(i+1)+'A" '+ simdisbProps.get("finDisb"+ String(i+1)+"A_ENABLED") + ' style="text-align:left;width: 100px">';
			tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(i+1)+'B" id="finDisb'+ String(i+1)+'B" '+ simdisbProps.get("finDisb"+ String(i+1)+"B_ENABLED") + ' style="text-align:left;width: 100px">';
			tbody+='</td>';
			//tbody+='<span style="color:red">  *</span></td>';
			tbody+='</tr>';
			//}
			
		//}
	}
	
	tbody+='<tr>';
	tbody+='<td>&nbsp; &nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td class="textlabel" >' + "" + '</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  	
	tbody+='<td class="textfield" align="center">';  
	//tbody+='<input type="text" class="textfieldfont" name="phoneNo" id="phoneNo" style="width: 135px">';  
	tbody+='<input id="Del" name="Del" type="button" class="button"	onClick="javascript:return delRecord();"" value="Del" hotKeyId="Del">';
	tbody+='</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ' + "Total Disbursed" + '';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.indAmtVal" id="indAmtVal" ' + simdisbProps.get("indAmtVal_ENABLED") + ' style="border:0px;background-color:white;width:117px">';
	tbody+='</td>';
	tbody+='<td>';
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.DenomAmtCrncy" id="DenomAmtCrncy" ' + simdisbProps.get("DenomAmtCrncy_ENABLED") + ' style="border:0px;background-color:white;width: 30px;border:0px">';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ';
	tbody+='</td>';
	tbody+='</tr>';	
	tbody+='</table>'
	document.getElementById("sumTable").tBodies[0].setAttribute("id","tableSumGen");
	body=document.getElementById("tableSumGen");
	var temp = body.ownerDocument.createElement("div");

	temp.innerHTML=tbody;
	body.parentNode.replaceChild(temp.firstChild.firstChild, body);
	
	var id=10;
	//alert(numbs2)
	j=0
	var cifId = document.getElementById("cifId").value
	for (i=1;i<=cifId;i++){
		//alert(document.getElementById("Denom"+String(i)+"1").checked);
		if (document.getElementById("Denom"+String(i)+"1").checked) {
			var chrgType = document.getElementById("Denom"+String(i)+"2").value
			var chrgEvent = document.getElementById("Denom"+String(i)+"3").value
			var chrgAmt = document.getElementById("Denom"+String(i)+"6").value
			var srlNum =document.getElementById("Denom"+String(i)+"7").value
			var DenomAmtCrncy = document.getElementById("DenomAmtCrncy").value
			
			
			var inputNameValues = "chrgType|"+chrgType+"|chrgEvent|"+chrgEvent+"|DenomAmtCrncy|"+DenomAmtCrncy+"|srlNum|"+srlNum;
			var outputNames = "corpAmtVal|acctAcCode|msg";
			var scrName ="simdisbmn003.scr";
			var retVal = appFnExecuteScript(inputNameValues,outputNames,scrName,true);
			corpAmtVal = document.getElementById("corpAmtVal").value
			//alert(corpAmtVal);
			acctAcCode = document.getElementById("acctAcCode").value
			//alert(acctAcCode);
			//if(i==1){
				j=j+1	
			//}
			
			document.getElementById("finDisb"+String(j)+"1").value = "";
			document.getElementById("finDisb"+String(j)+"2").value = "";
			document.getElementById("finDisb"+String(j)+"3").value = "";
			document.getElementById("finDisb"+String(j)+"8").value="CR"
			document.getElementById("finDisb"+String(j)+"5").value= corpAmtVal;
			document.getElementById("finDisb"+String(j)+"6").value= acctAcCode;
			document.getElementById("finDisb"+String(j)+"7").value= chrgAmt;
			document.getElementById("finDisb"+String(j)+"9").value= chrgType+"+"+chrgEvent+"+"+arr4[1]+"+"+chrgAmt+"+"+srlNum;
			document.getElementById("finDisb"+String(j)+"A").value= noRec
			
			document.getElementById("finDisb"+String(j)+"1").disabled=true
			document.getElementById("finDisb"+String(j)+"2").disabled=true
			document.getElementById("finDisb"+String(j)+"3").disabled=true
			document.getElementById("finDisb"+String(j)+"5").disabled=true
			document.getElementById("finDisb"+String(j)+"6").disabled=true
			document.getElementById("finDisb"+String(j)+"7").disabled=true
			document.getElementById("finDisb"+String(j)+"8").disabled=true
			
			document.getElementById("finDisb"+String(j+1)+"1").value = "";
			document.getElementById("finDisb"+String(j+1)+"2").value = "";
			document.getElementById("finDisb"+String(j+1)+"3").value = "";
			document.getElementById("finDisb"+String(j+1)+"8").value="DR"
			//alert(document.getElementById("tranTypeNet").checked)
			if(document.getElementById("tranTypeNet").checked ==true){
				//alert("IN")
				document.getElementById("finDisb"+String(j+1)+"5").value= document.getElementById("acctNo").value;
			}else{
				//alert("Not in")
				document.getElementById("finDisb"+String(j+1)+"5").value= arr4[1];
			}
			document.getElementById("finDisb"+String(j+1)+"6").value= arr5[1];
			document.getElementById("finDisb"+String(j+1)+"7").value= chrgAmt;
			document.getElementById("finDisb"+String(j+1)+"9").value= chrgType+"+"+chrgEvent+"+"+arr4[1]+"+"+chrgAmt+"+"+srlNum;
			document.getElementById("finDisb"+String(j+1)+"A").value= noRec;
			//alert(String(j+1))
			//alert(Number(numbs1)-1)
			/*if(String(j+1) == String(Number(numbs1))){
				document.getElementById("finDisb"+String(j+1)+"1").value = "";
				document.getElementById("finDisb"+String(j+1)+"2").value = "";
				document.getElementById("finDisb"+String(j+1)+"3").value = "";
				document.getElementById("finDisb"+String(j+1)+"8").value="DR"
				document.getElementById("finDisb"+String(j+1)+"5").value= document.getElementById("acctNo").value;
				document.getElementById("finDisb"+String(j+1)+"6").value= acctAcCode;
				document.getElementById("finDisb"+String(j+1)+"7").value= chrgAmt;
			}*/
			document.getElementById("finDisb"+String(j+1)+"1").disabled=true
			document.getElementById("finDisb"+String(j+1)+"2").disabled=true
			document.getElementById("finDisb"+String(j+1)+"3").disabled=true
			document.getElementById("finDisb"+String(j+1)+"5").disabled=true
			document.getElementById("finDisb"+String(j+1)+"6").disabled=true
			document.getElementById("finDisb"+String(j+1)+"7").disabled=true
			document.getElementById("finDisb"+String(j+1)+"8").disabled=true
			
			j=j+1
			//alert(j)
			
		}
	}
	document.getElementById("finDisb"+String(11)).value = arr1[1]
	document.getElementById("finDisb"+String(12)).value = arr2[1]
	document.getElementById("finDisb"+String(13)).value = arr3[1]
	//document.getElementById("finDisb"+String(14)).checked = true
	//alert(j);
	//alert(String(j+1)+"5");
	document.getElementById("finDisb"+String(j+1)+"5").value = arr4[1]
	document.getElementById("finDisb"+String(j+1)+"6").value = arr5[1]
	document.getElementById("finDisb"+String(j+1)+"7").value = arr6[1]
	document.getElementById("finDisb"+String(j+1)+"8").value = arr7[1]
	document.getElementById("finDisb"+String(j+1)+"A").value = noRec
	
	document.getElementById("finDisb"+String(j+2)+"5").value = document.getElementById("acctNo").value;
	document.getElementById("finDisb"+String(j+2)+"6").value = document.getElementById("AcctName").value;
	document.getElementById("finDisb"+String(j+2)+"7").value = document.getElementById("disbAmt").value;
	document.getElementById("finDisb"+String(j+2)+"8").value = "DR";
	//alert("finDisb"+String(j+2)+"A")
	//alert(noRec)
	document.getElementById("finDisb"+String(j+2)+"A").value = noRec;
	
	document.getElementById("finDisb"+String(j+1)+"5").disabled=true
	document.getElementById("finDisb"+String(j+1)+"6").disabled=true
	document.getElementById("finDisb"+String(j+1)+"7").disabled=true
	document.getElementById("finDisb"+String(j+1)+"8").disabled=true
	
	document.getElementById("finDisb"+String(j+2)+"5").disabled=true
	document.getElementById("finDisb"+String(j+2)+"6").disabled=true
	document.getElementById("finDisb"+String(j+2)+"7").disabled=true
	document.getElementById("finDisb"+String(j+2)+"8").disabled=true
	
	document.getElementById("finDisb"+String(id+1)).disabled=true
	document.getElementById("finDisb"+String(id+2)).disabled=true
	document.getElementById("finDisb"+String(id+3)).disabled=true
	document.getElementById("finDisb"+String(id+8)).disabled=true
	document.getElementById("finDisb"+String(id+5)).disabled=true
	document.getElementById("finDisb"+String(id+6)).disabled=true
	document.getElementById("finDisb"+String(id+7)).disabled=true
		
	
}

function addeTable(noRec,numbs1){
	var tbody="<table border=0>";
	var id=0;
	//arr1="";
	var arr1 = new Array();
	var arr2 = new Array();
	var arr3 = new Array();
	var arr4 = new Array();
	var arr5 = new Array();
	var arr6 = new Array();
	var arr7 = new Array();
	var arr8 = new Array();
	var arr9 = new Array();
	var k = document.getElementById("AD1").value
	//alert(num)
	//var id=11;
	//alert(numbs)
	//alert(numbs1)
	for (i=1;i<=numbs1;i++){
		//alert("finDisb"+String(i)+"1")
		//alert(document.getElementById("finDisb"+String(i)+"1").value)
		arr1[i] = document.getElementById("finDisb"+String(i)+"1").value ;
		arr2[i] = document.getElementById("finDisb"+String(i)+"2").value ;
		arr3[i] = document.getElementById("finDisb"+String(i)+"3").value ;
		arr4[i] = document.getElementById("finDisb"+String(i)+"5").value ;
		arr5[i] = document.getElementById("finDisb"+String(i)+"6").value ;
		arr6[i] = document.getElementById("finDisb"+String(i)+"7").value ;
		arr7[i] = document.getElementById("finDisb"+String(i)+"8").value ;
		arr8[i] = document.getElementById("finDisb"+String(i)+"9").value ;
		arr9[i] = document.getElementById("finDisb"+String(i)+"A").value ;
	}
	if(document.getElementById("AD1").value ==""){
		k=0
	}else{
		
		//alert(k)
		numbs1=Number(k)+numbs1+2
		document.getElementById("nfiu").value =numbs1
	}
	for (i=1;i<=numbs1;i++){
		
		id+=10
		//alert(String(id+1))
		tbody+='<tr>';
		//tbody+='<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090216") + "";
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<img  alt="Modify Record" id="'+ String(i)+'" border="0" height="17" hotKeyId="search1" src="../Renderer/images/'+applangcode+'/explode.gif" width="16" onclick="javascript:fetchRecMod(this);" >';
		tbody+='<input type="text"  class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+1)+'" id="finDisb'+ String(id+1)+'" '+ simdisbProps.get("finDisb"+ String(id+1)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+2)+'" id="finDisb'+ String(id+2)+'" '+ simdisbProps.get("finDisb"+ String(id+2)+"_ENABLED") + ' style="text-align:right;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+3)+'" id="finDisb'+ String(id+3)+'" '+ simdisbProps.get("finDisb"+ String(id+3)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">&nbsp;';
		tbody+='<input type="checkbox" name="finDisb'+ String(id+4)+'" id="finDisb'+ String(id+4)+'" >';
		tbody+='</td>';
		tbody+='<td >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+5)+'" id="finDisb'+ String(id+5)+'" '+ simdisbProps.get("finDisb"+ String(id+5)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+6)+'" id="finDisb'+ String(id+6)+'" '+ simdisbProps.get("finDisb"+ String(id+6)+"_ENABLED") + ' style="text-align:left;width: 200px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+7)+'" id="finDisb'+ String(id+7)+'" '+ simdisbProps.get("finDisb"+ String(id+7)+"_ENABLED") + ' style="text-align:right;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+8)+'" id="finDisb'+ String(id+8)+'" '+ simdisbProps.get("finDisb"+ String(id+8)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+9)+'" id="finDisb'+ String(id+9)+'" '+ simdisbProps.get("finDisb"+ String(id+9)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(i)+'A" id="finDisb'+ String(i)+'A" '+ simdisbProps.get("finDisb"+ String(i)+"A_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		//tbody+='<span style="color:red">  *</span></td>';
		tbody+='</tr>';
	}
	
	tbody+='<tr>';
	tbody+='<td>&nbsp; &nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td class="textlabel" >' + "" + '</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  	
	tbody+='<td class="textfield" align="center">';  
	//tbody+='<input type="text" class="textfieldfont" name="phoneNo" id="phoneNo" style="width: 135px">';  
	tbody+='<input id="Del" name="Del" type="button" class="button"	onClick="javascript:return delRecord();"" value="Del" hotKeyId="Del">';
	tbody+='</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ' + "Total Disbursed" + '';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.indAmtVal" id="indAmtVal" ' + simdisbProps.get("indAmtVal_ENABLED") + ' style="border:0px;background-color:white;width:117px">';
	tbody+='</td>';
	tbody+='<td>';
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.DenomAmtCrncy" id="DenomAmtCrncy" ' + simdisbProps.get("DenomAmtCrncy_ENABLED") + ' style="border:0px;background-color:white;width: 30px;border:0px">';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ';
	tbody+='</td>';
	tbody+='</tr>';	
	tbody+='</table>'
	document.getElementById("sumTable").tBodies[0].setAttribute("id","tableSumGen");
	body=document.getElementById("tableSumGen");
	var temp = body.ownerDocument.createElement("div");

	temp.innerHTML=tbody;
	body.parentNode.replaceChild(temp.firstChild.firstChild, body);
	var blank=0
	//alert(numbs1)
	//document.getElementById("nfiu").value =numbs1
	if(document.getElementById("AD1").value !=""){
		numbs1=numbs1-2
	}
	for (i=1;i<=numbs1-k;i++){
		//alert(arr1[i])
		if(arr1[i] ==""){
			if(blank==0){
				document.getElementById("finDisb"+String(i)+"1").style.visibility = 'visible'
				document.getElementById("finDisb"+String(i)+"2").style.visibility = 'visible'
				document.getElementById("finDisb"+String(i)+"3").style.visibility = 'visible'
				document.getElementById("finDisb"+String(i)+"4").style.visibility = 'visible'
				document.getElementById("finDisb"+String(i)+"1").value = document.getElementById("lastName").value ;
				document.getElementById("finDisb"+String(i)+"2").value = document.getElementById("address2").value ;
				document.getElementById("finDisb"+String(i)+"3").value = document.getElementById("firstName").value ;
				document.getElementById("finDisb"+String(i)+"5").value = arr4[i] ;
				document.getElementById("finDisb"+String(i)+"6").value = arr5[i] ;
				document.getElementById("finDisb"+String(i)+"7").value = arr6[i] ; 
				document.getElementById("finDisb"+String(i)+"8").value = arr7[i] ;
				document.getElementById("finDisb"+String(i)+"9").value = arr8[i] ;
				//alert(arr9[i])
				document.getElementById("finDisb"+String(i)+"A").value = arr9[i] ;
				blank=1
			}else{
				document.getElementById("finDisb"+String(i)+"1").value = arr1[i] ;
				document.getElementById("finDisb"+String(i)+"2").value = arr2[i] ;
				document.getElementById("finDisb"+String(i)+"3").value = arr3[i] ;
				document.getElementById("finDisb"+String(i)+"1").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(i)+"2").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(i)+"3").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(i)+"4").style.visibility = 'hidden'
				document.getElementById(String(i)).style.visibility = 'hidden'
				document.getElementById("finDisb"+String(i)+"5").value = arr4[i] ;
				document.getElementById("finDisb"+String(i)+"6").value = arr5[i] ;
				document.getElementById("finDisb"+String(i)+"7").value = arr6[i] ; 
				document.getElementById("finDisb"+String(i)+"8").value = arr7[i] ;
				document.getElementById("finDisb"+String(i)+"9").value = arr8[i] ;
				document.getElementById("finDisb"+String(i)+"A").value = arr9[i] ;
			}
		}else{
			document.getElementById("finDisb"+String(i)+"1").value = arr1[i] ;
			document.getElementById("finDisb"+String(i)+"2").value = arr2[i] ;
			document.getElementById("finDisb"+String(i)+"3").value = arr3[i] ;
			document.getElementById("finDisb"+String(i)+"5").value = arr4[i] ;
			document.getElementById("finDisb"+String(i)+"6").value = arr5[i] ;
			document.getElementById("finDisb"+String(i)+"7").value = arr6[i] ; 
			document.getElementById("finDisb"+String(i)+"8").value = arr7[i] ;
			document.getElementById("finDisb"+String(i)+"9").value = arr8[i] ;
			document.getElementById("finDisb"+String(i)+"A").value = arr9[i] ;
		}
		
		document.getElementById("finDisb"+String(i)+"1").disabled=true
		document.getElementById("finDisb"+String(i)+"2").disabled=true
		document.getElementById("finDisb"+String(i)+"3").disabled=true
		document.getElementById("finDisb"+String(i)+"5").disabled=true
		document.getElementById("finDisb"+String(i)+"6").disabled=true
		document.getElementById("finDisb"+String(i)+"7").disabled=true
		document.getElementById("finDisb"+String(i)+"8").disabled=true
		
		document.getElementById("AD2").value=i
	}
	//alert(noRec)
	if(k !=0) {
		cifId = document.getElementById("cifId").value
		j=document.getElementById("AD2").value
		for (i=1;i<=cifId;i++){
			//alert(document.getElementById("Denom"+String(i)+"1").checked);
			if (document.getElementById("Denom"+String(i)+"1").checked) {
				var chrgType = document.getElementById("Denom"+String(i)+"2").value
				var chrgEvent = document.getElementById("Denom"+String(i)+"3").value
				var chrgAmt = document.getElementById("Denom"+String(i)+"6").value
				var srlNum =document.getElementById("Denom"+String(i)+"7").value
				var DenomAmtCrncy = document.getElementById("DenomAmtCrncy").value
				
				
				var inputNameValues = "chrgType|"+chrgType+"|chrgEvent|"+chrgEvent+"|DenomAmtCrncy|"+DenomAmtCrncy+"|srlNum|"+srlNum;
				var outputNames = "corpAmtVal|acctAcCode|msg";
				var scrName ="simdisbmn003.scr";
				var retVal = appFnExecuteScript(inputNameValues,outputNames,scrName,true);
				corpAmtVal = document.getElementById("corpAmtVal").value
				//alert(corpAmtVal);
				acctAcCode = document.getElementById("acctAcCode").value
				//alert(acctAcCode);
				//if(i==1){
					j=Number(j)+1	
				//}
				document.getElementById("finDisb"+String(j)+"1").value = "";
				document.getElementById("finDisb"+String(j)+"2").value = "";
				document.getElementById("finDisb"+String(j)+"3").value = "";
				document.getElementById("finDisb"+String(j)+"8").value="CR"
				document.getElementById("finDisb"+String(j)+"5").value= corpAmtVal;
				document.getElementById("finDisb"+String(j)+"6").value= acctAcCode;
				document.getElementById("finDisb"+String(j)+"7").value= chrgAmt;
				document.getElementById("finDisb"+String(j)+"9").value= chrgType+"+"+chrgEvent+"+"+document.getElementById("lastName").value+"+"+chrgAmt+"+"+srlNum;
				document.getElementById("finDisb"+String(j)+"A").value= noRec
				
				document.getElementById("finDisb"+String(j)+"1").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(j)+"2").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(j)+"3").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(j)+"4").style.visibility = 'hidden'
				document.getElementById(String(j)).style.visibility = 'hidden'
				
				/*document.getElementById("finDisb"+String(j)+"1").disabled=true
				document.getElementById("finDisb"+String(j)+"2").disabled=true
				document.getElementById("finDisb"+String(j)+"3").disabled=true*/
				document.getElementById("finDisb"+String(j)+"5").disabled=true
				document.getElementById("finDisb"+String(j)+"6").disabled=true
				document.getElementById("finDisb"+String(j)+"7").disabled=true
				document.getElementById("finDisb"+String(j)+"8").disabled=true
				
				document.getElementById("finDisb"+String(j+1)+"1").value = "";
				document.getElementById("finDisb"+String(j+1)+"2").value = "";
				document.getElementById("finDisb"+String(j+1)+"3").value = "";
				document.getElementById("finDisb"+String(j+1)+"8").value="DR"
				document.getElementById("finDisb"+String(j+1)+"5").value= document.getElementById("lastName").value
				//alert(document.getElementById("address1").value);
				document.getElementById("finDisb"+String(j+1)+"6").value= document.getElementById("address1").value;
				document.getElementById("finDisb"+String(j+1)+"7").value= chrgAmt;
				document.getElementById("finDisb"+String(j+1)+"9").value= chrgType+"+"+chrgEvent+"+"+document.getElementById("lastName").value+"+"+chrgAmt+"+"+srlNum;
				document.getElementById("finDisb"+String(j+1)+"A").value= noRec
				
				document.getElementById("finDisb"+String(j+1)+"1").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(j+1)+"2").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(j+1)+"3").style.visibility = 'hidden'
				document.getElementById("finDisb"+String(j+1)+"4").style.visibility = 'hidden'
				document.getElementById(String(j+1)).style.visibility = 'hidden'
				
				/*document.getElementById("finDisb"+String(j+1)+"1").disabled=true
				document.getElementById("finDisb"+String(j+1)+"2").disabled=true
				document.getElementById("finDisb"+String(j+1)+"3").disabled=true*/
				document.getElementById("finDisb"+String(j+1)+"5").disabled=true
				document.getElementById("finDisb"+String(j+1)+"6").disabled=true
				document.getElementById("finDisb"+String(j+1)+"7").disabled=true
				document.getElementById("finDisb"+String(j+1)+"8").disabled=true
				
				j=j+1
				//alert(j)
				
			}
		}
		//alert(noRec)
		document.getElementById("finDisb"+String(id-10+1)).style.visibility = 'hidden'
		document.getElementById("finDisb"+String(id-10+2)).style.visibility = 'hidden'
		document.getElementById("finDisb"+String(id-10+3)).style.visibility = 'hidden'
		document.getElementById("finDisb"+String(id-10+4)).style.visibility = 'hidden'
		document.getElementById(String(j+1)).style.visibility = 'hidden'
		document.getElementById(String(j+2)).style.visibility = 'hidden'
		document.getElementById("finDisb"+String(id-10+8)).value="DR"
		document.getElementById("finDisb"+String(id-10+5)).value= document.getElementById("acctNo").value;
		document.getElementById("finDisb"+String(id-10+6)).value= document.getElementById("AcctName").value;
		document.getElementById("finDisb"+String(id-10+7)).value= document.getElementById("disbAmt").value;
		//alert("finDisb"+String(id-10+7))
		//alert("finDisb"+String(j+1)+"A")
		document.getElementById("finDisb"+String(j+1)+"A").value= noRec
		document.getElementById("finDisb"+String(j+2)+"A").value= noRec
		
		document.getElementById("finDisb"+String(id-10+8)).disabled=true
		document.getElementById("finDisb"+String(id-10+5)).disabled=true
		document.getElementById("finDisb"+String(id-10+6)).disabled=true
		document.getElementById("finDisb"+String(id-10+7)).disabled=true
	}
	//alert("First")
	//alert(String(id))
	if(String(id) =="10"){
		//alert("2nd")
		document.getElementById("finDisb"+String(id+1)).value = document.getElementById("lastName").value ;
		document.getElementById("finDisb"+String(id+2)).value = document.getElementById("address2").value ;
		document.getElementById("finDisb"+String(id+3)).value = document.getElementById("firstName").value ;
	}
	//id = id-10
	
	
	document.getElementById("finDisb"+String(id+1)).style.visibility = 'hidden'
	document.getElementById("finDisb"+String(id+2)).style.visibility = 'hidden'
	document.getElementById("finDisb"+String(id+3)).style.visibility = 'hidden'
	document.getElementById("finDisb"+String(id+4)).style.visibility = 'hidden'
	document.getElementById("finDisb"+String(id+8)).value="CR"
	document.getElementById("finDisb"+String(id+5)).value= document.getElementById("lastName").value;
	document.getElementById("finDisb"+String(id+6)).value= document.getElementById("address1").value;
	document.getElementById("finDisb"+String(id+7)).value= document.getElementById("address2").value;
	
	document.getElementById("finDisb"+String(id+1)).disabled=true
	document.getElementById("finDisb"+String(id+2)).disabled=true
	document.getElementById("finDisb"+String(id+3)).disabled=true
	document.getElementById("finDisb"+String(id+8)).disabled=true
	document.getElementById("finDisb"+String(id+5)).disabled=true
	document.getElementById("finDisb"+String(id+6)).disabled=true
	document.getElementById("finDisb"+String(id+7)).disabled=true
	
	
	
}

function remRecTable(len){
	var tbody="<table border=0>";
	var id=0;
	var s=1;
	var d=1
	//arr1="";
	var arr1 = new Array();
	var arr2 = new Array();
	var arr3 = new Array();
	var arr4 = new Array();
	var arr5 = new Array();
	var arr6 = new Array();
	var arr7 = new Array();
	var arr8 = new Array();
	var arr9 = new Array();
	var arrs1 = new Array();
	var arrs2 = new Array();
	var arrs3 = new Array();
	//alert(len)
	//var id=11;
	//alert(numbs)
	//alert(numbs1)
	var l=0
	var numbs1 =document.getElementById("nfiu").value 
	for (i=1;i<=numbs1;i++){
		//alert("finDisb"+String(i)+"1")
		//alert(document.getElementById("finDisb"+String(i)+"1").value)
		if(document.getElementById("finDisb"+String(i)+"4").checked){
			arrs1[i] =""
			arrs2[i] =""
			arrs3[i] =""
		}else{
			arrs1[i] = document.getElementById("finDisb"+String(i)+"1").value ;
			arrs2[i] = document.getElementById("finDisb"+String(i)+"2").value ;
			arrs3[i] = document.getElementById("finDisb"+String(i)+"3").value ;
			//alert(document.getElementById("finDisb"+String(i)+"A").value)
			//alert(i)
			for (q=1;q<=numbs1;q++){
				if(document.getElementById("finDisb"+String(q)+"A").value == i){
					//alert("IN")
					document.getElementById("finDisb"+String(q)+"A").value = d
				}
			}
			d = d+1
		}
		if(document.getElementById("finDisb"+String(i)+"A").value !="Y"){
			//alert("finDisb"+String(i)+"1")
			l=l+1
			arr1[s] = document.getElementById("finDisb"+String(i)+"1").value ;
			arr2[s] = document.getElementById("finDisb"+String(i)+"2").value ;
			arr3[s] = document.getElementById("finDisb"+String(i)+"3").value ;
			arr4[s] = document.getElementById("finDisb"+String(i)+"5").value ;
			arr5[s] = document.getElementById("finDisb"+String(i)+"6").value ;
			arr6[s] = document.getElementById("finDisb"+String(i)+"7").value ;
			arr7[s] = document.getElementById("finDisb"+String(i)+"8").value ;
			arr8[s] = document.getElementById("finDisb"+String(i)+"9").value ;
			arr9[s] = document.getElementById("finDisb"+String(i)+"A").value ;
			s=s+1
		}
	}

	for (i=1;i<=len;i++){
		
		id+=10
		//alert(String(id+1))
		tbody+='<tr>';
		//tbody+='<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090216") + "";
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<img  alt="Modify Record" id="'+ String(i)+'" border="0" height="17" hotKeyId="search1" src="../Renderer/images/'+applangcode+'/explode.gif" width="16" onclick="javascript:fetchRecMod(this);" >';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+1)+'" id="finDisb'+ String(id+1)+'" '+ simdisbProps.get("finDisb"+ String(id+1)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+2)+'" id="finDisb'+ String(id+2)+'" '+ simdisbProps.get("finDisb"+ String(id+2)+"_ENABLED") + ' style="text-align:right;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+3)+'" id="finDisb'+ String(id+3)+'" '+ simdisbProps.get("finDisb"+ String(id+3)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">&nbsp;';
		tbody+='<input type="checkbox" name="finDisb'+ String(id+4)+'" id="finDisb'+ String(id+4)+'" >';
		tbody+='</td>';
		tbody+='<td >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+5)+'" id="finDisb'+ String(id+5)+'" '+ simdisbProps.get("finDisb"+ String(id+5)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+6)+'" id="finDisb'+ String(id+6)+'" '+ simdisbProps.get("finDisb"+ String(id+6)+"_ENABLED") + ' style="text-align:left;width: 200px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+7)+'" id="finDisb'+ String(id+7)+'" '+ simdisbProps.get("finDisb"+ String(id+7)+"_ENABLED") + ' style="text-align:right;width: 100px">';
		tbody+='</td>';
		tbody+='<td class="textfield" style="width: 117px">';
		tbody+='<input type="text" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+8)+'" id="finDisb'+ String(id+8)+'" '+ simdisbProps.get("finDisb"+ String(id+8)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(id+9)+'" id="finDisb'+ String(id+9)+'" '+ simdisbProps.get("finDisb"+ String(id+9)+"_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='<input type="hidden" class="textfieldfont" name="'+ subGroupName + '.finDisb'+ String(i)+'A" id="finDisb'+ String(i)+'A" '+ simdisbProps.get("finDisb"+ String(i)+"A_ENABLED") + ' style="text-align:left;width: 100px">';
		tbody+='</td>';
		//tbody+='<span style="color:red">  *</span></td>';
		tbody+='</tr>';
	}
	
	tbody+='<tr>';
	tbody+='<td>&nbsp; &nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td class="textlabel" >' + "" + '</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  	
	tbody+='<td class="textfield" align="center">';  
	//tbody+='<input type="text" class="textfieldfont" name="phoneNo" id="phoneNo" style="width: 135px">';  
	tbody+='<input id="Del" name="Del" type="button" class="button"	onClick="javascript:return delRecord();"" value="Del" hotKeyId="Del">';
	tbody+='</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';  
	tbody+='<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
	tbody+='</tr>';
	
	tbody+='<tr>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ' + "Total Disbursed" + '';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.indAmtVal" id="indAmtVal" ' + simdisbProps.get("indAmtVal_ENABLED") + ' style="border:0px;background-color:white;width:117px">';
	tbody+='</td>';
	tbody+='<td>';
	tbody+='<input type="text" class="textfieldfont" name="' + subGroupName + '.DenomAmtCrncy" id="DenomAmtCrncy" ' + simdisbProps.get("DenomAmtCrncy_ENABLED") + ' style="border:0px;background-color:white;width: 30px;border:0px">';
	tbody+='</td>';
	tbody+='<td>'; 
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td>';
	tbody+='</td>';
	tbody+='<td> ';
	tbody+='</td>';
	tbody+='</tr>';	
	tbody+='</table>'
	document.getElementById("sumTable").tBodies[0].setAttribute("id","tableSumGen");
	body=document.getElementById("tableSumGen");
	var temp = body.ownerDocument.createElement("div");

	temp.innerHTML=tbody;
	body.parentNode.replaceChild(temp.firstChild.firstChild, body);
	var blank=0
	//alert(numbs1)
	document.getElementById("nfiu").value=len
	for (i=1;i<=len;i++){
		//alert(arr9[i])
		if(arrs1[i] ==""){
			document.getElementById("finDisb"+String(i)+"1").value = arrs1[i] ;
			document.getElementById("finDisb"+String(i)+"2").value = arrs1[i] ;
			document.getElementById("finDisb"+String(i)+"3").value = arrs1[i] ;
			document.getElementById("finDisb"+String(i)+"1").style.visibility = 'hidden'
			document.getElementById("finDisb"+String(i)+"2").style.visibility = 'hidden'
			document.getElementById("finDisb"+String(i)+"3").style.visibility = 'hidden'
			document.getElementById("finDisb"+String(i)+"4").style.visibility = 'hidden'
			document.getElementById(String(i)).style.visibility = 'hidden'
			document.getElementById("finDisb"+String(i)+"5").value = arr4[i] ;
			document.getElementById("finDisb"+String(i)+"6").value = arr5[i] ;
			document.getElementById("finDisb"+String(i)+"7").value = arr6[i] ; 
			document.getElementById("finDisb"+String(i)+"8").value = arr7[i] ;
			document.getElementById("finDisb"+String(i)+"9").value = arr8[i] ;
			document.getElementById("finDisb"+String(i)+"A").value = arr9[i] ;
			
		}else{
			document.getElementById("finDisb"+String(i)+"1").value = arrs1[i] ;
			document.getElementById("finDisb"+String(i)+"2").value = arrs2[i] ;
			document.getElementById("finDisb"+String(i)+"3").value = arrs3[i] ;
			document.getElementById("finDisb"+String(i)+"5").value = arr4[i] ;
			document.getElementById("finDisb"+String(i)+"6").value = arr5[i] ;
			document.getElementById("finDisb"+String(i)+"7").value = arr6[i] ; 
			document.getElementById("finDisb"+String(i)+"8").value = arr7[i] ;
			document.getElementById("finDisb"+String(i)+"9").value = arr8[i] ;
			document.getElementById("finDisb"+String(i)+"A").value = arr9[i] ;
		}
		if(i >1){
			//alert(arrs1[i-1])
			if(arrs1[i] !=""){
				if(arrs1[i-1] ==""){
					document.getElementById("finDisb"+String(i-1)+"1").value = arrs1[i] ;
					document.getElementById("finDisb"+String(i-1)+"2").value = arrs2[i] ;
					document.getElementById("finDisb"+String(i-1)+"3").value = arrs3[i] ;
					document.getElementById("finDisb"+String(i-1)+"1").style.visibility = 'visible'
					document.getElementById("finDisb"+String(i-1)+"2").style.visibility = 'visible'
					document.getElementById("finDisb"+String(i-1)+"3").style.visibility = 'visible'
					document.getElementById("finDisb"+String(i-1)+"4").style.visibility = 'visible'
					document.getElementById(String(i-1)).style.visibility = 'visible'
					document.getElementById("finDisb"+String(i)+"1").value =""
					document.getElementById("finDisb"+String(i)+"2").value =""
				    document.getElementById("finDisb"+String(i)+"3").value =""
					document.getElementById("finDisb"+String(i)+"1").style.visibility = 'hidden'
					document.getElementById("finDisb"+String(i)+"2").style.visibility = 'hidden'
					document.getElementById("finDisb"+String(i)+"3").style.visibility = 'hidden'
					document.getElementById("finDisb"+String(i)+"4").style.visibility = 'hidden'
					document.getElementById(String(i)).style.visibility = 'hidden'
				}
				
			}
		}
		
		document.getElementById("finDisb"+String(i)+"1").disabled=true
		document.getElementById("finDisb"+String(i)+"2").disabled=true
		document.getElementById("finDisb"+String(i)+"3").disabled=true
		document.getElementById("finDisb"+String(i)+"5").disabled=true
		document.getElementById("finDisb"+String(i)+"6").disabled=true
		document.getElementById("finDisb"+String(i)+"7").disabled=true
		document.getElementById("finDisb"+String(i)+"8").disabled=true

	}
}



function MonitorKeyPress2(e)
{
	var demonValAll;
	demonValAll = document.getElementById("Denom"+e).value;
	var denomRep = demonValAll.replace(/[^0-9]+/,"");
	document.getElementById("Denom"+e).value = denomRep;
}

function rmZero(e){
	
	var demonValAll;
	demonValAll = document.getElementById("Denom"+e).value;
	
	if (demonValAll == "0"){
		
		document.getElementById("Denom"+e).value = "0";
		document.getElementById("Denom"+e).focus;
	}
}

function rmZero2(e){
	
	var demonValAll;
	demonValAll = document.getElementById("Denom"+e).value;
	
	if (demonValAll == "0"){
		document.getElementById("Denom"+e).value = "";
		
	}
}



function memPadExst() {
    //if (funcCode == "A" || funcCode == "M") {
        var vPtrnAcctId = document.getElementById("acctNo").value.toUpperCase();
        if (vPtrnAcctId != "") {
            var inputNameValues = "vPtrnAcctId|" + vPtrnAcctId;
            var outputNames = "messg";
            var scrName = "memPadExst.scr";
            var retVal = appFnExecuteScript(inputNameValues, outputNames, scrName, false);
            var messg = retVal.split("|");
            if (messg[1] != undefined) {
                var memStr = messg[1];
                sTemp = memStr.split("XX");
                sNew = "";
                for (i = 0; i < sTemp.length; i++) {
                    if (sTemp[i] != "0") sNew = sNew + "\n" + sTemp[i];
                }
                alert("******MEMOPAD DETAILS******\n" + sNew);
            }
        }
    //}
}

function fieldTrimmer(object){
	value=object.value;
	value = value.replace(/\s/gi,"");
	object.value = value;
}
//

function isDigit(arg){
	state=arg.match(/^[0-9]+$/);
	if ((state==null) || (arg.length!=11)){
		return false;
	}else{
		return true;
	}
}




