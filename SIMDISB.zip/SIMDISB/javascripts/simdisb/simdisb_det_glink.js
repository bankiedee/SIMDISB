function printBlock()
{
	writeCustomHeader("simdisb_det");
	with (document){
	write('<input type="hidden" id="custType"  name="' + subGroupName + '.custType">');
	write('<input type="hidden" id="cifId" ' + simdisbProps.get("cifId_ENABLED") + ' name="' + subGroupName + '.cifId">');
	write('<input type="hidden" id="CFN"' + simdisbProps.get("CFN_ENABLED") + '  name="' + subGroupName + '.CFN">');
	write('<input type="hidden" id="CLN" ' + simdisbProps.get("CLN_ENABLED") + ' name="' + subGroupName + '.CLN">');
	write('<input type="hidden" id="AD1" ' + simdisbProps.get("sal_ENABLED") + ' name="' + subGroupName + '.AD1">');
	write('<input type="hidden" id="AD2" ' + simdisbProps.get("sal_ENABLED") + ' name="' + subGroupName + '.AD2">');
	write('<input type="hidden" id="PNO" ' + simdisbProps.get("PNO_ENABLED") + ' name="' + subGroupName + '.PNO">');
	write('<input type="hidden" id="sal" ' + simdisbProps.get("sal_ENABLED") + ' name="' + subGroupName + '.sal" >');
	write('<input type="hidden" id="cCode" ' + simdisbProps.get("cCode_ENABLED") + ' name="' + subGroupName + '.cCode">');
	write('<input type="hidden" id="action" ' + simdisbProps.get("action_ENABLED") + ' name="' + subGroupName + '.action">');
	write('<input type="hidden" id="noRec" name="' + subGroupName + '.noRec">');
	write('<input type="hidden" id="hdisb" name="' + subGroupName + '.hdisb">');
	write('<input type="hidden" id="userAcCode" name="' + subGroupName + '.userAcCode">');
	write('<input type="hidden" id="acctAcCode" name="' + subGroupName + '.acctAcCode">');
	//write('<input type="hidden" id="indAmtVal" name="' + subGroupName + '.indAmtVal">');
	write('<input type="hidden" id="corpAmtVal" name="' + subGroupName + '.corpAmtVal">');
	write('<input type="hidden" id="nfiu" name="' + subGroupName + '.nfiu">');
	write('<input type="hidden" id="msg" name="' + subGroupName + '.msg">');
	write('<input type="hidden" id="Err" name="' + subGroupName + '.Err">'); 
	write('<table border="0" cellspacing="0" cellpadding="0" class="ctable">');
	write('<tr>');
	write('<td>');
	write('<table border="0" cellspacing="0" cellpadding="0">');
	write('<tr>');
	write('<td class="page-heading">' + jspResArr.get("FLT090227") + '</td>');
	write('</tr>');
	write('</table>');
	write('<table border="0" cellpadding="0" cellspacing="0" width="100%">');
	write('<tr>');
	write('<td class="textlabel">' + jspResArr.get("FLT090228") + '</td>');
	write('<td class="textfielddisplaylabel"> </td>');
	write('<td class="columnwidth">&nbsp; </td>');
	write('<td class="textlabel">  </td>');
	write('<td class="textfielddisplaylabel"> </td>');
	write('</tr>');
	write('</table>');
	write('<br />');
	write('<!-- DETAILSBLOCK-BEGIN -->');
	write('<table border="0" cellpadding="0" cellspacing="0" width="100%">');
	write('<tr>');
	write('<td valign="top">');
	write('<table width="100%" border="0" cellpadding="0" cellspacing="0" class="table">');
	write('<tr>');
	write('<td>');
	write('<table width="100%" border="0" cellpadding="0" cellspacing="0" class="innertable">');
	write('<tr>');
	write('<td>');
	write('<table border="0" cellpadding="0" cellspacing="0" class="innertabletop1">');
	
	
	write('<tr>');
	write('<td class="textlabel" style="height: 15px; width: 250px;color:green"><font size="2">' + jspResArr.get("FLT00023") +' </font></td>');
	write('<span style="color:red"></span></td>');
	write('<td class="textlabel">');
	
	write('</td>');
	write('<td class="textlabel" style="width: 250px">' + jspResArr.get("FLT014274") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.solId" id="solId" ' + simdisbProps.get("solId_ENABLED") + ' style="width: 117px;border:0px;display:hidden;background-color:white;">');
	write('</td>');
	write('</tr>');
	
	write('<tr>');
	write('<td class="textlabel" style="height: 15px; width: 250px">' + jspResArr.get("FLT021862") + '</td>');
	write('<td class="textfield" style="width: 150px">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.tranDate" id="tranDate" ' + simdisbProps.get("tranDate_ENABLED") + ' onchange="fieldTrimmer(this);" style="width: 117px;border:0px;background-color:white">');
	write('</td>');
	write('<td class="textlabel">' + "Value Date" + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.valDate" id="valDate" ' + simdisbProps.get("valDate_ENABLED") + ' style="width: 150px;">');
	write('</td>');
	write('</tr>');
	
	write('<tr>');
	write('<td class="textlabel" style="height: 15px ; width: 250px">' + "Function" + "");
	write('<span style="color:red">  *</span></td>');
	write('<td class="textfield" style="height: 15px ; width: 150px">');
	write('<select style="height: 15px ; width: 150px" name="' + subGroupName + '.funcCode" id="funcCode" ' + simdisbProps.get("funcCode_ENABLED") + '" style="width: 218px" onChange="javascript:return fetchDepDetails();" >');
	//write('<option value="SELECT" id="SELECT">' + jspResArr.get("FLT090147") + '</option>');
	write('<option value="D" id="D">' + "D-DISBURSEMENT" + '</option>');
	write('<option value="M" id="M">' + "M-MODIFY" + '</option>');
	write('<option value="X" id="X">' + "X-CANCEL" + '</option>');
	write('<option value="V" id="V">' + "V-VERIFY" + '</option>');
	write('<option value="R" id="R">' + "R-REVERSAL" + '</option>');
	write('</select>');
	write('</td>');
	write('<td class="textlabel" style="height: 15px; width: 250px">' + "Transaction Type" + '</td>');
	write('<td class="textfield" style="width: 117px">');
	write('<input type="radio" value="C" name="' + subGroupName + '.tranType" id="tranTypeCash" >Cash');
	write('<input type="radio" value="T" name="' + subGroupName + '.tranType" id="tranTypeTran" checked>Transfer');
	write('</td>');
	write('</tr>');
	
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090216") + "");
	write('<span style="color:red">  *</span></td>');
	write('<td class="textfield">');
	write('<input type="number" class="textfieldfont" name="' + subGroupName + '.acctNo" id="acctNo" ' + simdisbProps.get("acctNo_ENABLED") + ' style="width: 150px" onchange="fieldTrimmer(this); fetchDepDetails()" >');
	write('&nbsp;<a href="javascript:showAccountIdList(document.forms[0].acctNo);document.getElementById(\'acctNo\').onchange();">');
	write('<img border="0" height="17" hotKeyId="search1" src="../Renderer/images/'+applangcode+'/search_icon.gif" width="16">');
	write('</a>');
	write('<input hotKeyId="search1" type="text" class="textfieldfont" name="' + subGroupName + '.crcnyCode" id="crcnyCode" ' + simdisbProps.get("crcnyCode_ENABLED") + ' style="width: 50px;border:0px;background-color:white;">');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090217") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.AcctName" id="AcctName" ' + simdisbProps.get("AcctName_ENABLED") + ' style="width: 300px;border:0px;background-color:white;">');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	
	write('<tr>');
	write('<td class="textlabel" style="height: 15px; width: 250px">' + jspResArr.get("FLT090220") + "");
	write('<span style="color:red">  *</span></td>');
	write('<td class="textfield" style="width: 250px">');
	write('<input type="number" class="textfieldfont" name="' + subGroupName + '.amt" id="amt" ' + simdisbProps.get("amt_ENABLED") + ' style="text-align:right;width: 150px"  >');
	write('</td>');
	write('<td class="textlabel" style="width: 250px">' + "Loan Period (Month/Days)" + "");
	write('<span style="color:red">  *</span></td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.mnth"  id="mnth" ' + simdisbProps.get("mnth_ENABLED") + ' style="width: 50px;border:0px;background-color:white;">');
	write('<input hotKeyId="search1" type="text" class="textfieldfont" name="' + subGroupName + '.dayM" id="dayM" ' + simdisbProps.get("dayM_ENABLED") + ' style="width: 50px;border:0px;background-color:white;">');
	write('</td>');
	write('</tr>');
	
	write('<tr>');
	write('<td class="textlabel" style="height: 15px; width: 250px">' + "Loan Amt. Disbursed" + "");
	write('<span style="color:red">  *</span></td>');
	write('<td class="textfield" style="width: 283px">');
	write('<input type="number" class="textfieldfont" name="' + subGroupName + '.disbdAmt" id="disbdAmt" ' + simdisbProps.get("disbdAmt_ENABLED") + ' style="text-align:right;width: 150px" >');
	write('</td>');
	write('<td class="textlabel" style="width: 250px">' + "Disbursement Amt." + "");
	write('<span style="color:red">  *</span></td>');
	write('<td class="textfield">');
	write('<input type="number" class="textfieldfont" name="' + subGroupName + '.disbAmt" id="disbAmt" ' + simdisbProps.get("disbAmt_ENABLED") + ' style="width: 150px" onchange="decLiterals2(this); fetchDepDetails1(this)" >');
	//write('<input type="text" onChange="javascript:return fetchDepDetails();" class="textfieldfont" name="' + subGroupName + '.disbAmt"  id="disbAmt" ' + simdisbProps.get("disbAmt_ENABLED") + ' style="width: 150px"  >');
	//write('<input hotKeyId="search1" type="text" class="textfieldfont" name="' + subGroupName + '.dayM" id="dayM" ' + simdisbProps.get("dayM_ENABLED") + ' style="width: 50px;border:0px;background-color:white;">');
	write('</td>');
	write('</tr>');
	
	write('<tr>');
	write('<td class="textlabel" style="height: 15px; width: 250px">' + "Available for disbursement" + "");
	write('<span style="color:red">  *</span></td>');
	write('<td class="textfield" style="width: 283px">');
	write('<input type="number" class="textfieldfont" name="' + subGroupName + '.availDisbAmt" id="availDisbAmt" ' + simdisbProps.get("availDisbAmt_ENABLED") + ' style="text-align:right;width: 150px" >');
	write('</td>');
	write('<td class="textlabel" style="height: 15px; width: 250px">' + "Gross/ Net Disbursement" + '</td>');
	write('<td class="textfield" style="width: 117px">');
	write('<input type="radio" value="G" name="' + subGroupName + '.groNetDisb" id="tranTypeGross"  checked>Gross');
	write('<input type="radio" value="N" name="' + subGroupName + '.groNetDisb" id="tranTypeNet"  >Net');
	write('</td>');
	write('</tr>');
	
	write('<tr>');
	write('<td class="textlabel" style="height: 15px; width: 250px">' + "Total Disbursement Amt." + "");
	write('<span style="color:red">  *</span></td>');
	write('<td class="textfield" style="width: 283px">');
	write('<input type="number" class="textfieldfont" name="' + subGroupName + '.totDisbAmts" id="totDisbAmts" ' + simdisbProps.get("totDisbAmts_ENABLED") + ' style="text-align:right;width: 150px" onchange="decLiterals2(this); fetchDepDetails1(this);">');
	write('</td>');
	write('<td class="textlabel" style="height: 15px; width: 250px">' + "Final Disbursement" + '</td>');
	write('<td class="textfield" style="width: 117px">');
	write('<input type="radio" value="Y" name="' + subGroupName + '.finDisb" id="finDisbYes"  >Yes');
	write('<input type="radio" value="N" name="' + subGroupName + '.finDisb" id="finDisbNo" checked>No');
	write('</td>');
	write('</tr>');
	write('<tr>');
	write('<td class="searcheader1a" style="width: 250px;"><font size="2">' + "Loan Fee Assessment Details" + '');
	write('</font>');
	write('</td>');
	write('<td class="textfield" style="width: 283px">');
	//write('<input type="number" class="textfieldfont" name="' + subGroupName + '.availDisbAmt" id="availDisbAmt" ' + simdisbProps.get("availDisbAmt_ENABLED") + ' style="text-align:right;width: 200px" onblur="decLiterals2()">');
	write('</td>');
	write('<td class="textlabel" style="width: 250px;color:blue"><font size="2">' + "" + '</font></td>');
	write('<td class="textfield" style="width: 117px">');
	//write('<input type="radio" value="1" name="' + subGroupName + '.finDisb" id="finDisbYes" onclick="valNFIU();">Yes');
	//write('<input type="radio" value="0" name="' + subGroupName + '.finDisb" id="finDisbNo" onclick="valNFIU();">No');
	write('</td>');
	write('</tr>');
		
	write('</table>');
	

//LoanAccessment table
	
write('<div class="col-md-8 col-md-offset-2" ><table align="left">');
write('<tr>');
write('<td>	');
write('<table border="0" id="denomTable" cellspacing="0" cellpadding="0" >');
write('<thead>');
write('<tr>');
write('<th style="width: 20px;" class="searcheader1a">' + "Select" + '</th>');
write('<th class="searcheader1a">' + "Charge Type"+ '</th>');
write('<th class="searcheader1a">' + "Charge Event ID" + '</th>');
write('<th class="searcheader1a">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>');
write('<th class="searcheader1a">' + "System Cal.Amt" + '</th>');
write('<th class="searcheader1a">' + "Fee(%)" + '</th>');
write('<th class="searcheader1a">' + "Calc. Amt" + '</th>');
write('<th class="searcheader1a" border="1"><font size="2">' + "Loan Disbursement Details" + '</th>')
//write('<th class="searcheader1a">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>');
write('</tr>');
write('</thead>');	



write('<tbody  id="tableGenerate">');


write('</tbody>');

 
write('</table>');
write('</tr>');
write('</table></div>');
//

//summary table
	
write('<div class="col-md-8 col-md-offset-2" ><table align="left">');
write('<tr>');
write('<td>	');
write('<table border="0" id="sumTable" cellspacing="0" cellpadding="0" >');
write('<col>');
write('<colgroup span="2"></colgroup>');
write('<colgroup span="2"></colgroup>');
write('<thead>');
write('<tr>');
write('<th colspan="2" scope="colgroup" class="searcheader1a" border="1"><font size="2">' + "Loan Disbursement Summary" + '</th>');
write('<th class="searcheader1a">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>')
write('<th class="searcheader1a">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>')
write('<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>')
write('<th colspan="2" scope="colgroup" class="searcheader1a" border="1"><font size="2">' + "Loan Disbursement Accounting Entries" + '</th>');
write('<th class="searcheader1a">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>')
write('<th class="searcheader1a">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>')
write('</tr>');
write('<tr>');
//write('<td> ');
//write('<table align="top" border="1"cellspacing="0" style="border-width:0 0 0 0;">');
write('<th scope="col" class="searcheader1a" border="1">' + "Credit Acc. No" + '</th>');
write('<th scope="col" class="searcheader1a" border="1">' + "Credit Amt." + '</th>');
write('<th scope="col" class="searcheader1a" border="1">' + "Disb. Code" + '</th>');
write('<th scope="col" class="searcheader1a" border="1">');
write('<input type="checkbox" name="checkAll1" id="checkAll1" onchange="takeRec(this)" onkeyup="takeRec(this)" onmousedown="takeRec(this)" onfocus="takeRec(this)" >');
write('</th>');
write('<th >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>')
write('<th scope="col" class="searcheader1a" border="1">' + "Acc ID" + '</th>');
write('<th scope="col" class="searcheader1a" border="1">' + "Acc Name" + '</th>');
write('<th scope="col" class="searcheader1a" border="1">' + "Amount" + '</th>');
write('<th scope="col" class="searcheader1a" border="1">' + "CR/DR" + '</th>');
write('</tr>');
write('</thead>');	
write('<tbody  id="tableSumGen">');

write('</tbody>');

 
write('</table>');
write('</tr>');
write('</table></div>');
//
	
	write('</td>');
	write('</tr>');
	write('</table>');
	write('</td>');
	write('</tr>');
	write('</table>');
	write('</td>');
	write('</tr>');
	write('</table>');
	write('<!-- DETAILSBLOCK-END -->');
	write('</td>');
	write('</tr>');
	write('</table>');
	} //End with()
} //End function

function printFooterBlock()
{
with (document) {
	if ((sReferralMode == 'I')||(sReferralMode == 'S')){
	write('<div align="left" class="ctable">');
	if (sReferralMode == 'S'){
	write('<input type="button" class="Button" id="Submit" value="'+jspResArr.get("FLT000193")+ '" onClick="javascript:return doRefSubmit(this);" hotKeyId="Submit" >');
	}
	writeRefFooter();
	write('<input type="button" class="Button" id="_BackRef_" value="'+jspResArr.get("FLT001721")+ '" onClick="javascript:return doSubmit(this.id);" hotKeyId="Cancel" >');
	write('</div>');
	}else{
	if(funcCode !='I'){
	write('<div class="ctable">');
	//write('<input id="Submit" name="Save" type="button" class="button"	onClick="javascript:return simdisb_det_ONCLICK1(this,this);"" value="' + jspResArr.get("FLT000198") + '" hotKeyId="Save">');
	write('<input id="Submit" name="Submit" type="button" class="button"	onClick="javascript:return simdisb_det_ONCLICK1(this,this);"" value="Submit" hotKeyId="Submit">');
	//write('<input id="Validate" name="Validate" type="button" class="button" value="' + jspResArr.get("FLT000194") + '"	onClick="javascript:return simdisb_det_ONCLICK2(this,this);"" hotKeyId="Validate">');
	write('<input id="Cancel" name="Cancel" type="button" class="button" value="' + jspResArr.get("FLT001721") + '"	onClick="javascript:return simdisb_det_ONCLICK3(this,this.id);"" hotKeyId="Cancel">');
	}else{
	write('<div class="ctable">');
	write('<input class="button" type="button" id="Back" value="'+jspResArr.get("FLT026526")+ '" onClick="javascript:return doSubmit(this.id)" hotKeyId="Ok">');
	}
	writeFooter();
	write('</div>');
	}
	} //End with()
}//End function

function fnOnLoad()
{
	var ObjForm = document.forms[0];

	pre_ONLOAD('simdisb_det',this);

	var funcName = "this."+"locfnOnLoad";
	if(eval(funcName) != undefined){
		eval(funcName).call(this);
	}

	fnPopulateControlValues();

	if(funcCode =='V' || funcCode =='I' || funcCode =='D' || funcCode =='U' ||  funcCode =='X' || sReferralMode =='I' || sReferralMode =='S'){
		fnDisableFormDataControls('V',ObjForm,0);
	}
	fnPopUpExceptionWindow(ObjForm.actionCode);
	if((typeof(WF_IN_PROGRESS) != "undefined") && (WF_IN_PROGRESS == "PEAS")){
		checkCustErrExecNextStep(Message);
	}

	post_ONLOAD('simdisb_det',this);
	ObjForm.sal.value =0
}

function fnCheckMandatoryFields()
{
	var ObjForm = document.forms[0];

	return true;
}

function fnPopulateControlValues() 
{
	var ObjForm = document.forms[0];

	ObjForm.tranDate.value = tranDate;
	ObjForm.solId.value = solId;
	ObjForm.acctNo.value = acctNo;
	ObjForm.crcnyCode.value = crcnyCode;
	ObjForm.AcctName.value = AcctName;
	ObjForm.amt.value = amt;
	ObjForm.disbAmt.value = disbAmt;
	ObjForm.disbdAmt.value = disbdAmt;
	ObjForm.mnth.value = mnth;
	ObjForm.dayM.value = dayM;
	ObjForm.tranType.value = tranType;
	ObjForm.funcCode.value = funcCode;
	ObjForm.availDisbAmt.value = availDisbAmt;
	ObjForm.finDisb.value = finDisb;
	ObjForm.totDisbAmts.value = totDisbAmts;
	ObjForm.groNetDisb.value = groNetDisb;
	ObjForm.CLN.value = CLN;
	ObjForm.radPrntAdv.value = radPrntAdv;
	ObjForm.depBvnNo.value = depBvnNo;
	ObjForm.sal.value = sal;
	ObjForm.cCode.value = depBvnNo;
	ObjForm.AD1.value = AD1;
	ObjForm.AD2.value = AD2;
	ObjForm.PNO.value = PNO;
	ObjForm.cifId.value = cifId;
	ObjForm.CFN.value = CFN;
	ObjForm.noRec.value = noRec;
	ObjForm.hdisb.value = hdisb;
	ObjForm.checkAll1.value = checkAll1;
	
	ObjForm.action.value = action;
	ObjForm.nfiu.value = nfiu;
	ObjForm.roundOffAmt.value = roundOffAmt;
	fnCheckControls();

}

function fnCheckControls()
{
	var ObjForm = document.forms[0];

	checkRadio(ObjForm.yes,yes);
}


function simdisb_det_ONCLICK1(obj,p1)
{
	var retVal = "";
	if (preEventCall('simdisb_det',obj,'ONCLICK') == false) { 
		return false;
	}
	if ((retVal =  fnValAndSubmit(p1)) == false) {
		return false;
	}
	if (postEventCall('simdisb_det',obj,'ONCLICK') == false) { 
		return false;
	}
	return (retVal == undefined) ? true : retVal;
}

function simdisb_det_ONCLICK2(obj,p1)
{
	var retVal = "";
	if (preEventCall('simdisb_det',obj,'ONCLICK') == false) { 
		return false;
	}
	if ((retVal =  fnVal(p1)) == false) {
		return false;
	}
	if (postEventCall('simdisb_det',obj,'ONCLICK') == false) { 
		return false;
	}
	return (retVal == undefined) ? true : retVal;
}

function simdisb_det_ONCLICK3(obj,p1)
{
	var retVal = "";
	if (preEventCall('simdisb_det',obj,'ONCLICK') == false) { 
		return false;
	}
	if ((retVal =  doSubmit(p1)) == false) {
		return false;
	}
	if (postEventCall('simdisb_det',obj,'ONCLICK') == false) { 
		return false;
	}
	return (retVal == undefined) ? true : retVal;
}
function simdisb_det_ONBLUR1(obj,p1,p2)
{
	var retVal = "";
	if (preEventCall('simdisb_det',obj,'ONBLUR') == false) { 
		return false;
	}
	if ((retVal = onBlurFormatDate(p1)) == false) {
		return false;
	}
	if ((retVal = fnAssignDateOnEnter(p2)) == false) {
		return false;
	}
	if (postEventCall('simdisb_det',obj,'ONBLUR') == false) { 
		return false;
	}
	return (retVal == undefined) ? true : retVal;
}
function simdisb_det_ONBLUR2(obj,p1,p2)
{
	var retVal = "";
	if (preEventCall('simdisb_det',obj,'ONBLUR') == false) { 
		return false;
	}
	if ((retVal = onBlurFormatDate(p1)) == false) {
		return false;
	}
	if ((retVal = fnAssignDateOnEnter(p2)) == false) {
		return false;
	}
	if (postEventCall('simdisb_det',obj,'ONBLUR') == false) { 
		return false;
	}
	return (retVal == undefined) ? true : retVal;
}
